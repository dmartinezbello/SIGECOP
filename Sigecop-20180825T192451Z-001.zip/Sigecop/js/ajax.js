/* 
------------------------------------------------------------------------------------------------
Sistema para el control de proyectos socio tecnologico del UPT Ludovico Silva Punta de Mata
Nombre de documento: ajax.js
Trabajo de diseno y programacion: Daniel Martinez
Analisis de procesos: Daniel Martinez, Francismar Reyes
Tecnico de pruebas: Daniel Martinez, Francismar Reyes, Elisneldy Lezama
------------------------------------------------------------------------------------------------
*/

function limpiar()
{
	document.form1.reset();
	
}
//funcion para cargar mediante Ajax los municipios en un div llamado municipios, esta funcion es utilizada en la pagina
//reg-instuticiones.php
function load(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
document.getElementById("parroquias").innerHTML=xmlhttp.responseText;
document.getElementById('parroquias').style.display='none';
document.getElementById('comunidad').style.display='none';
}
}
xmlhttp.open("POST","http://localhost/Sigecop/paginas/municipios.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}

//funcion para cargar mediante Ajax las parroquias en un div llamado parroquias, esta funcion es utilizada en la pagina
//parroquias.php
function load2(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("parroquias").innerHTML=xmlhttp.responseText;
document.getElementById('parroquias').style.display='block';
document.getElementById('comunidad').style.display='none';
}
}
xmlhttp.open("POST","http://localhost/Sigecop/paginas/parroquias.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}

//funcion para cargar mediante Ajax las Comunidades en un div llamado Comunidad, esta funcion es utilizada en la pagina
//CargaComunidad.php
function cargaComunidad(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("comunidad").innerHTML=xmlhttp.responseText;
document.getElementById('comunidad').style.display='block';
}
}
xmlhttp.open("POST","http://localhost/Sigecop/paginas/cargaComunidad.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}


//funcion para cargar mediante Ajax las lineas de investigacion segun cada especialidad en un div llamado linea, esta funcion es utilizada en la pagina
//reg-proyecto.php
function carga_linea_investigacion(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("linea").innerHTML=xmlhttp.responseText;
document.getElementById("area").innerHTML=xmlhttp.responseText;
document.getElementById('area').style.display='none';
}
}
xmlhttp.open("POST","http://localhost/Sigecop/paginas/cargaLineasInv.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}


//funcion para cargar mediante Ajax las areas de desarrollo segun la linea de investigacion seleccionadaen un div llamado area, esta funcion es utilizada en la pagina
//cargaLineasIns.php
function carga_area_desarrollo(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("area").innerHTML=xmlhttp.responseText;
document.getElementById('area').style.display='block';
}
}
xmlhttp.open("POST","http://localhost/Sigecop/paginas/cargaAreaDesarrollo.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}

//funcion para cargar mediante Ajax los estudiantes segun su numero de cedula en un div llamado estudiante, esta funcion es utilizada en la pagina
//reg-est-tu-pro.php
function carga_estudiante(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("estudiante").innerHTML=xmlhttp.responseText;
document.getElementById('estudiante').style.display='block';
document.getElementById("estudiante").style.border="1px dashed #FF0000";
}
}
xmlhttp.open("POST","http://localhost/Sigecop/paginas/carga-estudiante.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}

//funcion para cargar mediante Ajax los estudiantes segun su numero de cedula en un div llamado estudiante, esta funcion es utilizada en la pagina
//reg-est-tu-pro.php
function carga_tutor(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("tutor").innerHTML=xmlhttp.responseText;
document.getElementById('tutor').style.display='block';
document.getElementById("tutor").style.border="1px dashed #FF0000";
}
}
xmlhttp.open("POST","http://localhost/Sigecop/paginas/carga-tutor.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}

//**************************************************************************************************************

