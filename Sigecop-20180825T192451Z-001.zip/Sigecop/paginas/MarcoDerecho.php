<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['usuario'])) {
  $loginUsername=$_POST['usuario'];
  $password=$_POST['pass'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "principal.php";
  $MM_redirectLoginFailed = "login-error.php";
  $MM_redirecttoReferrer = true;
  mysql_select_db($database_conex, $conex);
  
  $LoginRS__query=sprintf("SELECT TxLogUsu, TxPasUsu FROM usuarios WHERE TxLogUsu=%s AND TxPasUsu=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $conex) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && true) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
	echo "<script> if (parent.frames.length > 0) { parent.location.href = 'sigecop.php'}</script>";
	/*echo "<script type='text/javascript'> window.opener.location.reload();</script>";*/
	/*echo("<script language='javascript'>location.href='".$MM_redirectLoginSuccess."' target='mainFrame'  </script>");*/
    //header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
	  $error=1;
	 /* echo "<script type='text/javascript'> window.opener.location.reload();</script>";*/
	/*  echo("<script language='javascript'>location.href='".$MM_redirectLoginFailed."' target='mainFrame'  </script>");*/
    //header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
<title>Sigecop - Lateral izquierdo</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php if ($_SESSION['MM_Username']==""){ ?>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="15" style="border:1px solid #ececec;">
    
    <form name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
        <table width="100%" align="center" cellpadding="0" cellspacing="10">
          <tr>
            <td><h2>Iniciar sesi&oacute;n</h2></td>
          </tr>
          <tr>
            <td width="48%"><label><span class="icon-obligatorio der">&nbsp;&nbsp;&nbsp;</span> Usuario:</label>
              <input name="usuario" type="text" class="anchoFull" id="usuario"></td>
          </tr>
          <tr>
            <td><label for="textfield3">Contrase&ntilde;a:<span class="icon-obligatorio der">&nbsp;&nbsp;&nbsp;</span></label>
              <input name="pass" type="password" class="anchoFull" id="pass"></td>
          </tr>
          <tr>
            <td><input name="button" type="submit" class="button der" id="button" value="Registrar"></td>
          </tr>
          <tr>
            <td align="center"><?php if ($error==1){echo "<p class='obligatorio'>El proceso de inicio de sesion fallo, compruebe su nombre de usuario o contrasena</p>" ;} ?></td>
          </tr>
          <tr>
            <td align="center"><a href="olvido-clave.php" target="mainFrame">&iquest;Olvido su contrase&ntilde;a?</a></td>
          </tr>
        </table>
      </form>
      
      </td>
  </tr>
  <tr>
    <td height="5" class="Tcabeza">&nbsp;</td>
  </tr>
</table>
<?php }?>
</body>
</html>
