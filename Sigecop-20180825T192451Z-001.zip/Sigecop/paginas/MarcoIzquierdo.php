<?php require_once('../Connections/conex.php'); ?>
<?php
@session_start();
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_ObtenerNivel = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_ObtenerNivel = $_SESSION['MM_Username'];
}
mysql_select_db($database_conex, $conex);
$query_ObtenerNivel = sprintf("SELECT NuNivelUsu FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_ObtenerNivel, "text"));
$ObtenerNivel = mysql_query($query_ObtenerNivel, $conex) or die(mysql_error());
$row_ObtenerNivel = mysql_fetch_assoc($ObtenerNivel);
$totalRows_ObtenerNivel = mysql_num_rows($ObtenerNivel);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Accordion with CSS3</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
<style type="text/css">
a {
	display: block;
	max-width: 170px;
}
</style>
</head>
<body>
<div class="container">
  <section class="ac-container">
    <?php if ($_SESSION['MM_Username']<>""){ ?>
    <div>
      <input id="ac-1" name="accordion-1" type="radio" checked />
      <label for="ac-1"><span class="icon-proyectos">&nbsp;&nbsp;&nbsp;&nbsp;</span>Proyectos</label>
      <article class="ac-small">
        <?php if ($row_ObtenerNivel['NuNivelUsu']==3) {?>
        <a href="reg-proyecto.php" target="mainFrame"><span class="icon-nuevo">&nbsp;&nbsp;&nbsp;&nbsp;</span> Registro</a>
        <?php }?>
        <?php if ($row_ObtenerNivel['NuNivelUsu']==1 || $row_ObtenerNivel['NuNivelUsu']==3 || $row_ObtenerNivel['NuNivelUsu']==2) {?>
        <a href="reg-seguimiento.php" target="mainFrame"><span class="icon-seguimiento">&nbsp;&nbsp;&nbsp;&nbsp;</span>Seguimiento</a>
        <?php }?>
      </article>
    </div>
    <div>
      <input id="ac-2" name="accordion-1" type="radio" />
      <label for="ac-2"><span class="icon-consultas">&nbsp;&nbsp;&nbsp;&nbsp;</span> Consultas</label>
      <article class="ac-medium">
         <?php if ($row_ObtenerNivel['NuNivelUsu']==3) {?>
        <span class="icon-proyectos">&nbsp;&nbsp;&nbsp;&nbsp;</span>Listas
        <a href="con-aulas.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Aulas</a>
        <a href="con-docentes.php"  target="mainFrame"><span class="icon-vineta" >&nbsp;&nbsp;&nbsp;&nbsp;</span> Docentes</a>
        <a href="con-especialidades.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Especialidades</a>
        <a href="con-estudiantes.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Estudiantes</a>
        <a href="con-lineas.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> L&iacute;neas de investigaci&oacute;n</a>
        <a href="con-comunidades.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Comunidades</a>
        <a href="#"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Usuarios</a>
        <?php }?>
        <span class="icon-proyectos">&nbsp;&nbsp;&nbsp;&nbsp;</span>Proyectos
        <a href="con-trayectos.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por trayectos</a>
        <a href="con-estatus.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por estatus</a>
        <a href="con-lineaInv.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por lineas de investigaci&oacute;n</a>
        <a href="con-especialidad.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por Especialidades</a>
        <a href="con-docente.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por docente</a>
        <a href="con-docente-trayecto.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por docente y trayecto</a>
        <a href="con-estudiante.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por estudiantes</a>
        <a href="con-consignados.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Consignados</a>
        <a href="con-no-consignados.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Por Consignar</a>
        <span class="icon-historial">&nbsp;&nbsp;&nbsp;&nbsp;</span>Individuales
        <a href="con-docente-area.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Docentes por &aacute;reas de desarrollo</a>
        <a href="con-horario.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Horarios de presentaciones</a>
        <a href="con-evaluacion.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Evaluaci&oacute;n</a>
      </article>
    </div>
     <?php if ($row_ObtenerNivel['NuNivelUsu']==3) {?>
    <div>
      <input id="ac-3" name="accordion-1" type="radio" />
      <label for="ac-3"><span class="icon-operaciones">&nbsp;&nbsp;&nbsp;&nbsp;</span> Operaciones</label>
      <article class="ac-large">
        <span style="font-family:PTSansNarrow;">Proyectos</span>
        <a href="edi-proyecto.php" target="mainFrame"><span class="icon-modificar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Modificar proyectos</a>
        <a href="del-proyecto.php" target="mainFrame"><span class="icon-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Eliminar proyectos</a>
        <a href="reg-evaluacion.php" target="mainFrame"><span class="icon-evaluar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Evaluar proyectos</a>
        <br>
        <span style="font-family:PTSansNarrow;">Registrar</span>
        <a href="reg-estudiantes.php" title="Registrar estudiante" target="mainFrame"><span class="icon-registrar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Estudiante</a>
        <a href="reg-docentes.php" target="mainFrame"><span class="icon-registrar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Docentes</a>
        <a href="reg-lineasInv.php" target="mainFrame"><span class="icon-nuevo">&nbsp;&nbsp;&nbsp;&nbsp;</span>L&iacute;nea de investigaci&oacute;n</a>
        <a href="reg_instituciones.php" target="mainFrame"><span class="icon-nuevo">&nbsp;&nbsp;&nbsp;&nbsp;</span> Registrar comunidad</a>
        <!--<a href="#"><span class="icon-registrar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Registrar representante comunitario</a>-->
        <br>
        <span style="font-family:PTSansNarrow;">Organizar</span>
        <a href="reg-horario.php" target="mainFrame"><span class="icon-organizar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Presentaciones</a>
      </article>
    </div>
    <?php }?>
    <div>
      <input id="ac-4" name="accordion-1" type="radio" />
      <label for="ac-4"><span class="icon-gestion">&nbsp;&nbsp;&nbsp;&nbsp;</span> Gesti&oacute;n</label>
      <article class="ac-large">
        <span style="font-family:PTSansNarrow;">Actas</span>
        <a href="#"><span class="icon-acta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Aprobaci&oacute;n</a>
        <a href="#"><span class="icon-acta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Revision de proyecto</a>
        <a href="#"><span class="icon-acta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Final para tomos</a>
        <a href="#"><span class="icon-acta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Asignaci&oacute;n de jurado</a>
        <br>
        <span style="font-family:PTSansNarrow;">Usuarios</span>
        <a href="edi-pass.php" target="mainFrame"><span class="icon-actualizar">&nbsp;&nbsp;&nbsp;&nbsp;</span> Cambio de clave</a>
        <br>
        <a href="../ayuda/guiaDeProyecto.pdf" target="mainFrame"><span class="icon-manuales">&nbsp;&nbsp;&nbsp;&nbsp;</span> Manuales</a>
        <a href="contactos.php"  target="mainFrame"><span class="icon-contactos">&nbsp;&nbsp;&nbsp;&nbsp;</span> Contactos</a>
        <a href="../ayuda/Manual de Usuario.pdf" target="mainFrame"><span class="icon-ayuda">&nbsp;&nbsp;&nbsp;&nbsp;</span> Ayuda</a>
      </article>
    </div>
    <?php }?>
    <div>
      <input id="ac-5" name="accordion-1" type="radio" />
      <label for="ac-5"><span class="icon-historial">&nbsp;&nbsp;&nbsp;&nbsp;</span> Historial</label>
      <article class="ac-large">
        <a href="con-his-PNFE.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> PNFE</a>
        <a href="con-his-PNFI.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> PNFI</a>
        <a href="con-his-PNFHySL.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> PNFHySL</a>
        <a href="con-his-PNFIyC.php" target="mainFrame"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> PNFIyC</a>
      </article>
    </div>
    <div>
      <input id="ac-6" name="accordion-1" type="radio" />
      <label for="ac-6"><span class="icon-organizacion">&nbsp;&nbsp;&nbsp;&nbsp;</span> La Organizaci&oacute;n</label>
      <article class="ac-large">
        <a href="mision.php" target="mainFrame"><span class="icon-mision">&nbsp;&nbsp;&nbsp;&nbsp;</span> Misi&oacute;n</a>
        <a href="vision.php" target="mainFrame"><span class="icon-vision">&nbsp;&nbsp;&nbsp;&nbsp;</span> Visi&oacute;n</a>
        <a href="#"><span class="icon-estructura">&nbsp;&nbsp;&nbsp;&nbsp;</span> Estructura organizativa</a>
        <a href="#"><span class="icon-opiniones">&nbsp;&nbsp;&nbsp;&nbsp;</span> Opiniones</a>
      </article>
    </div>
  </section>
</div>
</body>
</html>
<?php
mysql_free_result($ObtenerNivel);
?>
