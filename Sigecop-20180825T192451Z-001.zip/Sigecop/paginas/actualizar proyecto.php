<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form13")) {
  $updateSQL = sprintf("UPDATE proyecto SET TxTitPro=%s, TxBenPro=%s, DtRegPro=%s, TxConPro=%s, AuNomIns=%s, TxEstPro=%s, AuCodAre=%s WHERE TxCodPro=%s",
                       GetSQLValueString($_POST['TxTitPro'], "text"),
                       GetSQLValueString($_POST['TxBenPro'], "text"),
                       GetSQLValueString($_POST['DtRegPro'], "date"),
                       GetSQLValueString($_POST['TxConPro'], "text"),
                       GetSQLValueString($_POST['AuNomIns'], "int"),
                       GetSQLValueString($_POST['TxEstPro'], "text"),
                       GetSQLValueString($_POST['AuCodAre'], "int"),
                       GetSQLValueString($_POST['TxCodPro'], "text"));
  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
}

$colname_Recordset1 = "-1";
if (isset($_POST['codigo'])) {
  $colname_Recordset1 = $_POST['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_Recordset1 = sprintf("SELECT * FROM proyecto WHERE TxCodPro = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $conex) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
</head>

<body>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right">TxCodPro:</td>
      <td><?php echo $row_Recordset1['TxCodPro']; ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">TxTitPro:</td>
      <td><input type="text" name="TxTitPro" value="<?php echo htmlentities($row_Recordset1['TxTitPro'], ENT_COMPAT, 'iso-8859-2'); ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">TxBenPro:</td>
      <td><input type="text" name="TxBenPro" value="<?php echo htmlentities($row_Recordset1['TxBenPro'], ENT_COMPAT, 'iso-8859-2'); ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">DtRegPro:</td>
      <td><input type="text" name="DtRegPro" value="<?php echo htmlentities($row_Recordset1['DtRegPro'], ENT_COMPAT, 'iso-8859-2'); ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">TxConPro:</td>
      <td><input type="text" name="TxConPro" value="<?php echo htmlentities($row_Recordset1['TxConPro'], ENT_COMPAT, 'iso-8859-2'); ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">AuNomIns:</td>
      <td><input type="text" name="AuNomIns" value="<?php echo htmlentities($row_Recordset1['AuNomIns'], ENT_COMPAT, 'iso-8859-2'); ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">TxEstPro:</td>
      <td><input type="text" name="TxEstPro" value="<?php echo htmlentities($row_Recordset1['TxEstPro'], ENT_COMPAT, 'iso-8859-2'); ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">AuCodAre:</td>
      <td><input type="text" name="AuCodAre" value="<?php echo htmlentities($row_Recordset1['AuCodAre'], ENT_COMPAT, 'iso-8859-2'); ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="Update record"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="TxCodPro" value="<?php echo $row_Recordset1['TxCodPro']; ?>">
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
