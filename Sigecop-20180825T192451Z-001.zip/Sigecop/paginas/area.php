<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php');?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE linea SET TxNomLin=%s WHERE AuCodLin=%s",
                       GetSQLValueString($_POST['TxNomLin'], "text"),
                       GetSQLValueString($_POST['AuCodLin'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
  echo "<script language='JavaScript'> alert('Fue actualizado el nombre de la linea de investigacion');</script>";
}

$colname_duplicado = "-1";
if (isset($_POST['TxDesAre'])) {
  $colname_duplicado = $_POST['TxDesAre'];
}
mysql_select_db($database_conex, $conex);
$query_duplicado = sprintf("SELECT * FROM area WHERE TxDesAre = %s AND NuCodLin = ".$_GET['linea']."", GetSQLValueString($colname_duplicado, "text"));
$duplicado = mysql_query($query_duplicado, $conex) or die(mysql_error());
$row_duplicado = mysql_fetch_assoc($duplicado);
$totalRows_duplicado = mysql_num_rows($duplicado);
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxDesAre'])&& !empty($_POST['AuCodEsp'])&& !empty($_POST['TxTraAre'])){
if ($totalRows_duplicado==0){
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO area (AuCodAre, TxDesAre, NuCodLin, AuCodEsp, TxTraAre) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodAre'], "int"),
                       GetSQLValueString($_POST['TxDesAre'], "text"),
                       GetSQLValueString($_GET['linea'], "int"),
							  GetSQLValueString($_POST['AuCodEsp'], "text"),
							  GetSQLValueString($_POST['TxTraAre'], "text")
							  );

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  $_POST = array();
}
}else{echo "<script language='JavaScript'> alert('Se detecto un intento de registro que no se llevo a cabo porque crearia una duplicidad');</script>";}
}else {$error=1;}
$maxRows_lineaInv = 10;
$pageNum_lineaInv = 0;
if (isset($_GET['pageNum_lineaInv'])) {
  $pageNum_lineaInv = $_GET['pageNum_lineaInv'];
}
$startRow_lineaInv = $pageNum_lineaInv * $maxRows_lineaInv;

$colname_lineaInv = "-1";
if (isset($_GET['linea'])) {
  $colname_lineaInv = $_GET['linea'];
}
mysql_select_db($database_conex, $conex);
$query_lineaInv = sprintf("SELECT * FROM linea WHERE AuCodLin = %s", GetSQLValueString($colname_lineaInv, "int"));
$query_limit_lineaInv = sprintf("%s LIMIT %d, %d", $query_lineaInv, $startRow_lineaInv, $maxRows_lineaInv);
$lineaInv = mysql_query($query_limit_lineaInv, $conex) or die(mysql_error());
$row_lineaInv = mysql_fetch_assoc($lineaInv);

if (isset($_GET['totalRows_lineaInv'])) {
  $totalRows_lineaInv = $_GET['totalRows_lineaInv'];
} else {
  $all_lineaInv = mysql_query($query_lineaInv);
  $totalRows_lineaInv = mysql_num_rows($all_lineaInv);
}
$totalPages_lineaInv = ceil($totalRows_lineaInv/$maxRows_lineaInv)-1;

$colname_areas = "-1";
if (isset($_GET['linea'])) {
  $colname_areas = $_GET['linea'];
}
mysql_select_db($database_conex, $conex);
$query_areas = sprintf("SELECT area.AuCodAre, area.TxDesAre, area.TxTraAre, especialidad.TxNomEsp FROM area, especialidad WHERE NuCodLin = %s AND especialidad.AuCodEsp=area.AuCodEsp ORDER BY TxDesAre, AuCodAre ASC", GetSQLValueString($colname_areas, "int"));
$areas = mysql_query($query_areas, $conex) or die(mysql_error());
$row_areas = mysql_fetch_assoc($areas);
$totalRows_areas = mysql_num_rows($areas);

mysql_select_db($database_conex, $conex);
$query_especialidad = "SELECT * FROM especialidad ORDER BY TxNomEsp ASC";
$especialidad = mysql_query($query_especialidad, $conex) or die(mysql_error());
$row_especialidad = mysql_fetch_assoc($especialidad);
$totalRows_especialidad = mysql_num_rows($especialidad);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>areas de desarrollo</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Asociar Areas de Desarrollo a L&iacute;neas de Investigaci&oacute;n</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td align="left"><table width="95%" align="center">
          <?php if (array_key_exists ('enviar', $_POST) && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
          <tr>
            <td><h2>Datos de linea de investigaci&oacute;n:</h2>
              <span class="der"><span class="icon-add">&nbsp;&nbsp;&nbsp;&nbsp;</span><a href="reg-lineasInv.php">Nueva linea de investigaci&oacute;n</a></span></td>
          </tr>
          <tr>
            <td align="left">
              <table width="100%" border="0" align="center" cellpadding="10" cellspacing="1">
                <tr>
                  <th align="left"><form method="post" name="form2" action="<?php echo $editFormAction; ?>">
                      <table width="100%" align="center">
                        <tr valign="baseline">
                          <td nowrap align="left"><label>Linea de investigacion:</label>
                          <input name="TxNomLin" type="text" class="textInput" value="<?php echo $row_lineaInv['TxNomLin']; ?>" size="32"></td>
                        </tr>
                        <tr valign="baseline">
                          <td nowrap align="right"><input name="otro" type="submit" class="button" id="otro" value="Actualizar"></td>
                        </tr>
                      </table>
                      <input type="hidden" name="MM_update" value="form2">
                      <input type="hidden" name="AuCodLin" value="<?php echo $row_lineaInv['AuCodLin']; ?>">
                    </form></th>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>
              <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
                <table width="100%" border="0" cellspacing="10" cellpadding="0">
                  <tr>
                    <td colspan="2">
                    <label>Area de desarrollo:<?php if (array_key_exists ('enviar', $_POST) && $_POST['AuTraLin'] == "") { echo $icono;}?></label>
                    <input name="TxDesAre" type="text" class="textInput" value="<?php if (isset($_POST['TxDesAre'])) {echo htmlentities($_POST['TxDesAre']);} ?>" size="32"></td>
                  </tr>
                  <tr>
                    <td width="80%"><label for="AuCodEsp">Especialidad
                      <?php if (array_key_exists ('enviar', $_POST) && $_POST['AuCodEsp'] == "") { echo $icono;}?>
                    </label>
                      <select name="AuCodEsp" class="textInput" id="AuCodEsp">
                        <option value="">Seleccione una opcion</option>
                        <?php
do {  
?>
                        <option value="<?php echo $row_especialidad['AuCodEsp']?>"><?php echo $row_especialidad['TxNomEsp']?></option>
                        <?php
} while ($row_especialidad = mysql_fetch_assoc($especialidad));
  $rows = mysql_num_rows($especialidad);
  if($rows > 0) {
      mysql_data_seek($especialidad, 0);
	  $row_especialidad = mysql_fetch_assoc($especialidad);
  }
?>
                    </select></td>
                    <td width="20%"><label for="TxTraAre">Trayecto
                      <?php if (array_key_exists ('enviar', $_POST) && $_POST['TxTraAre'] == "") { echo $icono;}?>
                    </label>
                      <select name="TxTraAre" class="textInput" id="TxTraAre">
                        <option value="">Seleccione una opcion</option>
                        <option value="1">Trayecto I</option>
                        <option value="2">Trayecto II</option>
                        <option value="3">Trayecto III</option>
                        <option value="4">Trayecto IV</option>
                    </select></td>
                  </tr>
                </table>
                <input name="enviar" type="submit" class="button der" id="enviar" value="Agregar">
                <input type="hidden" name="MM_insert" value="form1">
              </form></td>
          </tr>
          <tr>
            <td align="left">&nbsp;
              <table width="100%" border="0" cellpadding="10" cellspacing="1">
                <tr>
                  <th width="50%" align="left" class="Tcabeza">Descripci&oacute;n del area de desarrollo</th>
                  <th width="30%" align="left" class="Tcabeza">Especialidad</th>
                  <th width="10%" class="Tcabeza">Trayecto</th>
                  <th width="10%" class="Tcabeza">Eliminar</th>
                </tr>
                <?php do { ?>
                  <tr>
                    <td width="50%" class="lineaInfPunta"><?php echo $row_areas['TxDesAre']; ?></td>
                    <td width="30%" align="left" class="lineaInfPunta"><?php echo $row_areas['TxNomEsp']; ?></td>
                    <td width="10%" align="center" class="lineaInfPunta"><?php echo $row_areas['TxTraAre']; ?></td>
                    <td width="10%" align="center" class="lineaInfPunta"><a href="del-area.php?area=<?php echo $row_areas['AuCodAre']; ?>&linea=<?php echo $_GET['linea']; ?>"><span class="icon-del">&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
                  </tr>
                  <?php } while ($row_areas = mysql_fetch_assoc($areas)); ?>
              </table></td>
          </tr>
        </table></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($lineaInv);

mysql_free_result($areas);

mysql_free_result($especialidad);

mysql_free_result($duplicado);
?>
