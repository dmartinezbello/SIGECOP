<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
  
  echo "<script> if (parent.frames.length > 0) { parent.location.href = 'sigecop.php'}</script>";
	
//  $logoutGoTo = "principal.php";
//  if ($logoutGoTo) {
//    header("Location: $logoutGoTo");
//    exit;
//  }
}
?>
<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  <title>Untitled Document</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
  <style type="text/css">
.cabecera
{
   width: 100%;
   height: 90px;
   background-color: #06C;
   background: -moz-linear-gradient(top, #06C, #039);
   background: -webkit-gradient(linear, 0 0, 0 100%, from(#06C), to(#039));
 filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#0066CC', EndColorStr='#003399');
   box-shadow: 0px 3px 4px #ccc;
   -webkit-box-shadow: 3px 3px 4px #ccc;
   -moz-box-shadow: 3px 3px 4px #ccc;
}

.der
{
   float: right;
}

.izq
{
   float: left;
}

#nav ul
{
   list-style: none;
   display: table;
 *display: block;
   width: 100%;
   margin: 0;
   padding: 0;
}

#nav ul li
{
   display: table-cell;
 *display: inline;
   width: auto;
   min-width: 100px;
   border: 0px solid #999;
   text-align: center;
   white-space: nowrap;
}

a
{
   font-family: triplex;
}
</style>
</head>

<body>
  <div class="cabecera"> <img src="../img/LogoSigecop.png" width="96" height="87" alt="Sigecop" class="izq" style=" margin-left:18px; margin-top:0px;">
    <div class="titulo"> SIGECOP </div>
    <div class="subtitulo"> Sistema de Gesti&oacute;n y Control de Proyectos </div>
    <div class="subtitulo2"> Universidad Polit�cnica Territorial del Norte de Monagas "Ludovico Silva" Sede Punta de Mata </div>
    <img src="../img/Logo_Izq.jpg" width="100" height="90" alt="UPT Lusovico Silva" class="der"> </div>
  <div style="background:#ececec; height:30px;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="font-family:triplex; font-size:14px;" >
      <tr>
        <td width="240">
        <?php if ($_SESSION['MM_Username']<>"") {?>
        <span class="icon-online">&nbsp;</span>
          <ruby> <?php echo $_SESSION['MM_Username']; ?>
            <rt> <span style="font-family:PTSansNarrow; font-size:12px;"><strong>Sesi&oacute;n iniciada por:</strong></span></rt>
          </ruby>
          <?php }?>
        </td>
        <td align="center" valign="middle" style=" font-size:12px; "><div id="nav" style="padding-top:8px;">
            <ul>
              <li><a href="principal.php" target="mainFrame"><span class="icon-inicio">&nbsp;&nbsp;&nbsp;&nbsp;</span>Inicio</a></li>
            </ul>
          </div></td>
        <td width="240" align="right" valign="bottom">
        <?php if ($_SESSION['MM_Username']<>"") {?>
        <a href="<?php echo $logoutAction ?>" target="mainFrame"><span class="icon-logoff">&nbsp;&nbsp;&nbsp;&nbsp;</span>Cerrar Sesi&oacute;n&nbsp;</a>
        <?php }?>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>
