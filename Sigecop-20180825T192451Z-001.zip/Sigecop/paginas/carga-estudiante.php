 <?php
   include("../Connections/conex.php");
	$q=$_POST['q'];
   $link=conexion();
   $result=mysql_query("SELECT * FROM  estudiante WHERE  TxCedEst LIKE '%".$q."%'",$link) or die(mysql_error());
	$totalRows = mysql_num_rows($result);
if ($totalRows<>0){
  ?>
  
  <label>Registros ubicados:</label>
   <TABLE BORDER=0 CELLSPACING=1 CELLPADDING=5>
      <TR><th align="left">C&eacute;dula</th><th align="left">&nbsp;Apellidos&nbsp;</th>
        <th align="left">Nombres</th>
     </TR>
 <?php     
	
   while($row = mysql_fetch_array($result)) {
      printf("<tr><td>&nbsp;%s</td><td>&nbsp;%s&nbsp;</td><td>&nbsp;%s&nbsp;</td></tr>", $row["TxCedEst"],$row["TxApeEst"],$row["TxNomEst"]);
   }}else{echo 'No se han encontrado resultados...';}
   mysql_free_result($result);
   mysql_close($link);
  ?>

</table>