 <?php
   include("../Connections/conex.php");
	$q=$_POST['q'];
   $link=conexion();
   $result=mysql_query("SELECT * FROM  docente WHERE  NuCedDoc LIKE '%".$q."%'",$link) or die(mysql_error());
	$totalRows = mysql_num_rows($result);
if ($totalRows<>0){
  ?>
  
  <label>Registros ubicados:</label>
   <table border=0 cellspacing=1 cellpadding=5>
      <tr><th align="left">C&eacute;dula</th><th align="left">&nbsp;Apellidos&nbsp;</th>
        <th align="left">Nombres</th>
     </tr>
 <?php     
	
   while($row = mysql_fetch_array($result)) {
      printf("<tr><td>&nbsp;%s</td><td>&nbsp;%s&nbsp;</td><td>&nbsp;%s&nbsp;</td></tr>", $row["NuCedDoc"],$row["TxApeDoc"],$row["TxNomDoc"]);
   }}else{echo 'No se han encontrado resultados...';}
   mysql_free_result($result);
   mysql_close($link);
  ?>

</table>