<?php
include '../Connections/conex.php';
 
$q=$_POST['q'];
 
$res=mysql_query("SELECT AuCodAre, TxDesAre FROM  area WHERE  NuCodLin =".$q."",$conex);

?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
</head>
<body>
<label>&Aacute;rea de desarrollo:<?php if ($_POST && $_POST['AuCodAre'] == "0") { echo $icono;}?></label>
<select name="AuCodAre" id="AuCodAre" class="textInput">
<option value="0">Seleccione una opci&oacute;n</option> 
 
<?php while($fila=mysql_fetch_array($res)){ ?>
<option value="<?php echo $fila['AuCodAre']; ?>"><?php echo $fila['TxDesAre']; ?></option>
<?php } ?>
 
</select>
</body>
</html>
