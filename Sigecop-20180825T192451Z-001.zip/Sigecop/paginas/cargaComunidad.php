<?php
include '../Connections/conex.php';
 
$q=$_POST['q'];
 
$res=mysql_query("SELECT * FROM  institucion WHERE  NuCodPar =".$q."",$conex);

?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
</head>
<body>
<label>Comunidad:</label>
<select name="AuNomIns" id="AuNomIns" class="textInput">
<option value="0">Seleccione una opci&oacute;n</option> 
 
<?php while($fila=mysql_fetch_array($res)){ ?>
<option value="<?php echo $fila['AuCodIns']; ?>"><?php echo 'Instituci&oacute;n o concejo comunal '.$fila['TxNomIns']." de la comunidad del ".$fila['TxComIns']; ?></option>
<?php } ?>
 
</select>
</body>
</html>
