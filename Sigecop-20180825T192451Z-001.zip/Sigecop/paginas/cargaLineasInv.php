<?php
include '../Connections/conex.php';
 
$q=$_POST['q'];
$res=mysql_query("SELECT AuCodLin, TxNomLin  FROM  area, linea WHERE  AuCodEsp =".$q." AND AuCodLin = NuCodLin GROUP BY AuCodLin ORDER BY TxNomLin",$conex);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
</head>
<body>
<label>Lineas de investigaci&oacute;n:<?php if ($_POST && $_POST['areaInv'] == "0") { echo $icono;}?></label>
<select id="areaInv" class="textInput" onChange="carga_area_desarrollo(this.value)">
<option value="0">Seleccione una opci&oacute;n</option> 
 
<?php while($fila=mysql_fetch_array($res)){ ?>
<option value="<?php echo $fila['AuCodLin']; ?>"><?php echo $fila['TxNomLin']; ?></option>
<?php } ?>
</select>
</body>
</html>
