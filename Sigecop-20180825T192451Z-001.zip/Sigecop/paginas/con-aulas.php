<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_aulas = "SELECT * FROM aula ORDER BY TxNomAul ASC";
$aulas = mysql_query($query_aulas, $conex) or die(mysql_error());
$row_aulas = mysql_fetch_assoc($aulas);
$totalRows_aulas = mysql_num_rows($aulas);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
  <tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Lista de Aulas</h3></td>
  </tr>
  <tr>
    <td>&nbsp;
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <th colspan="2" align="right" class="icono"><a href="#" onclick="window.print();"><span class="icon-print">&nbsp;</span></a></th>
        </tr>
        <tr class="Tcabeza">
          <th width="20%" align="left">Aula</th>
          <th width="80%" align="left">Direcci&oacute;n</th>
        </tr>
        <?php do { ?>
          <tr>
            <td width="20%" class="lineaInfPunta"><?php echo $row_aulas['TxNomAul']; ?></td>
            <td width="80%" class="lineaInfPunta"><?php echo $row_aulas['TxDirAul']; ?></td>
          </tr>
          <?php } while ($row_aulas = mysql_fetch_assoc($aulas)); ?>
    </table><br></td>
</tr>
  <tr>
    <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr valign="baseline"> </tr>
      <tr valign="baseline"> </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($aulas);
?>
