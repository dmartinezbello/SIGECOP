<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_comunidades = "SELECT institucion.AuCodIns, institucion.TxNomIns, institucion.TxComIns, municipio.TxDesMun, estado.TxDesEst, municipio.TxDesMun, parroquia.TxDesPar FROM institucion, parroquia, municipio, estado WHERE institucion.NuCodPar=parroquia.NuCodPar AND parroquia.NuCodMun=municipio.NuCodMun AND municipio.NuCodEst=estado.NuCodEst ORDER BY TxNomIns ASC";
$comunidades = mysql_query($query_comunidades, $conex) or die(mysql_error());
$row_comunidades = mysql_fetch_assoc($comunidades);
$totalRows_comunidades = mysql_num_rows($comunidades);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
  <tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Lista de Instituciones por Comunidades</h3></td>
  </tr>
  <tr>
    <td>
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <td colspan="5" align="right" class="icono"><a href="#" onclick="window.print();"><span class="icon-print">&nbsp;</span></a></td>
        </tr>
        <tr class="Tcabeza">
          <th width="25%" align="left">Instituci&oacute;n</th>
          <th width="25%" align="left">Comunidad</th>
          <th width="15%" align="left">Estado</th>
          <th width="20%" align="left">Municipio</th>
          <th width="15%" align="left">Parroquia</th>
        </tr>
        <?php do { ?>
          <tr>
            <td width="25%" align="left" class="lineaInfPunta"><?php echo $row_comunidades['TxNomIns']; ?></td>
            <td width="25%" align="left" class="lineaInfPunta"><?php echo $row_comunidades['TxComIns']; ?></td>
            <td width="15%" align="left" class="lineaInfPunta"><?php echo $row_comunidades['TxDesEst']; ?></td>
            <td width="20%" align="left" class="lineaInfPunta"><?php echo $row_comunidades['TxDesMun']; ?></td>
            <td width="15%" align="left" class="lineaInfPunta"><?php echo $row_comunidades['TxDesPar']; ?></td>
          </tr>
          <?php } while ($row_comunidades = mysql_fetch_assoc($comunidades)); ?>
    </table></td>
</tr>
  <tr>
    <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr valign="baseline"> </tr>
      <tr valign="baseline"> </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($comunidades);
?>
