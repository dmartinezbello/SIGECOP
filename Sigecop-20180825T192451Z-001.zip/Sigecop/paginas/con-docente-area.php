<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_docente = "SELECT NuCedDoc, TxApeDoc, TxNomDoc FROM docente";
$docente = mysql_query($query_docente, $conex) or die(mysql_error());
$row_docente = mysql_fetch_assoc($docente);
$totalRows_docente = mysql_num_rows($docente);

mysql_select_db($database_conex, $conex);
$query_area = "SELECT area.TxDesAre, area.TxTraAre, especialidad.TxNomEsp, docentelinea.NuCedDoc, linea.TxNomLin FROM area, especialidad, docentelinea, docente, linea WHERE area.AuCodEsp=especialidad.AuCodEsp AND docentelinea.AuCodAre=area.AuCodAre AND docentelinea.NuCedDoc=docente.NuCedDoc AND docentelinea.NuCedDoc = '".$_POST['docente']."' AND linea.AuCodLin=area.NuCodLin";
$area = mysql_query($query_area, $conex) or die(mysql_error());
$row_area = mysql_fetch_assoc($area);
$totalRows_area = mysql_num_rows($area);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>docentes por areas de desarrrollo</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%">
    <tr>
      <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
    </tr>
    <tr>
      <td align="center"><h3>Lista de &Aacute;rea de Desarrollo por Docente </h3></td>
    </tr>
    <tr>
      <td><form name="form1" method="post" action="" class="icono">
        <fieldset>
          <legend>
          <h2>Parametros de Consulta</h2>
          </legend>
          <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
            <tr>
              <td width="60%"><label for="docente">Docente:
                
              </label>
                <select name="docente" class="textInput" id="docente">
                  <?php
do {  
?>
                  <option value="<?php echo $row_docente['NuCedDoc']?>"><?php echo $row_docente['NuCedDoc'].' - '.$row_docente['TxApeDoc'].', '.$row_docente['TxNomDoc']?></option>
                  <?php
} while ($row_docente = mysql_fetch_assoc($docente));
  $rows = mysql_num_rows($docente);
  if($rows > 0) {
      mysql_data_seek($docente, 0);
	  $row_docente = mysql_fetch_assoc($docente);
  }
?>
                </select></td>
            </tr>
            <tr>
              <td align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Buscar"></td>
            </tr>
            <tr>
              <?php if ($totalRows_area == 0) { // Show if recordset empty ?>
                <td colspan="4" align="left"><p class="obligatorio">No se encontraron registros...</p></td>
                <?php } // Show if recordset empty ?>
            </tr>
          </table>
        </fieldset>
      </form>
        <table width="95%" border="0" align="center" cellpadding="10" cellspacing="1">
          <tr>
            <th colspan="7">
            <span class="izq aparecer">Filtro:
				<?php  do {
                 if ($row_docente['NuCedDoc'] == $_POST['docente']){
                 echo 'Docente: '.$row_docente['NuCedDoc'].' - '.$row_docente['TxApeDoc'].', '.$row_docente['TxNomDoc'];}
                 } while ($row_docente = mysql_fetch_assoc($docente));
					  echo " / registros obtenidos (".$totalRows_area.")";
				?>
            </span>
            <a href="#" onClick="window.print();" class="icono"><span class="icon-print der">&nbsp;</span></a>
            </th>
          </tr>
          <?php if ($totalRows_area > 0) { // Show if recordset not empty ?>
  <tr class="Tcabeza">
    <th align="left">L&iacute;nea de investigaci&oacute;n</th>
    <th align="left">&Aacute;rea de desarrollo</th>
    <th align="left">Especialidad</th>
    <th>Trayecto</th>
  </tr>
  <?php } // Show if recordset not empty ?>
<?php do { ?>
            <tr>
              <td class="lineaInfPunta"><?php echo $row_area['TxNomLin']; ?></td>
              <td class="lineaInfPunta"><?php echo $row_area['TxDesAre']; ?></td>
              <td class="lineaInfPunta"><?php echo $row_area['TxNomEsp']; ?></td>
              <td class="lineaInfPunta" align="center"><?php echo $row_area['TxTraAre']; ?></td>
            </tr>
            <?php } while ($row_area = mysql_fetch_assoc($area)); ?>
        </table>
<br>
      </td>
    </tr>
    <tr>
      <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
        <tr valign="baseline"> </tr>
        <tr valign="baseline"> </tr>
      </table></td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($docente);

mysql_free_result($area);
?>
