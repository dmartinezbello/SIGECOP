<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_docentes = "SELECT * FROM docente ORDER BY TxApeDoc ASC";
$docentes = mysql_query($query_docentes, $conex) or die(mysql_error());
$row_docentes = mysql_fetch_assoc($docentes);
$totalRows_docentes = mysql_num_rows($docentes);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
  <tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Lista de Docentes</h3></td>
  </tr>
  <tr>
    <td>&nbsp;
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <th colspan="7" align="right" class="icono"><a href="#" onclick="window.print();"><span class="icon-print">&nbsp;</span></a></th>
        </tr>
        <tr class="Tcabeza">
          <th width="40%">Docente</th>
          <th width="30%">Contacto</th>
          <th width="30%">Direcci&oacute;n</th>
        </tr>
        <?php do { ?>
          <tr>
            <td width="30%" class="lineaInfPunta"><?php echo $row_docentes['NuCedDoc']; ?><br><?php echo $row_docentes['TxApeDoc']; ?>, <?php echo $row_docentes['TxNomDoc']; ?></td>
            <td width="30%" class="lineaInfPunta">Tel&eacute;fono Mov&iacute;l: <?php echo $row_docentes['TxMovilDoc']; ?><br>
              Tel&eacute;fono Fijo:  <?php echo $row_docentes['TxFIjoDoc']; ?><br>
              Correo electronico: <?php echo $row_docentes['TxEmailDoc']; ?></td>
            <td width="30%" class="lineaInfPunta"><?php echo $row_docentes['TxDirDoc']; ?></td>
          </tr>
          <?php } while ($row_docentes = mysql_fetch_assoc($docentes)); ?>
    </table><br></td>
</tr>
  <tr>
    <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr valign="baseline"> </tr>
      <tr valign="baseline"> </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($docentes);
?>
