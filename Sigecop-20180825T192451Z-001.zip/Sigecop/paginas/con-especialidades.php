<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_especialidades = "SELECT * FROM especialidad ORDER BY TxNomEsp ASC";
$especialidades = mysql_query($query_especialidades, $conex) or die(mysql_error());
$row_especialidades = mysql_fetch_assoc($especialidades);
$totalRows_especialidades = mysql_num_rows($especialidades);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
  <tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Lista de especialidades</h3></td>
  </tr>
  <tr>
    <td>&nbsp;<br>
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <td colspan="2" align="right" class="icono"><span class="icono"><a href="#" onclick="window.print();"><span class="icon-print">&nbsp;</span></a></span></td>
        </tr>
        <tr class="Tcabeza">
          <th width="90%" align="left">Especialidad</th>
          <th width="10%" align="left">Siglas</th>
        </tr>
        <?php do { ?>
          <tr>
            <td width="90%" class="lineaInfPunta"><?php echo $row_especialidades['TxNomEsp']; ?></td>
            <td width="10%" class="lineaInfPunta"><?php echo $row_especialidades['TxSigEsp']; ?></td>
          </tr>
          <?php } while ($row_especialidades = mysql_fetch_assoc($especialidades)); ?>
    </table></td>
</tr>
  <tr>
    <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr valign="baseline"> </tr>
      <tr valign="baseline"> </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($especialidades);
?>
