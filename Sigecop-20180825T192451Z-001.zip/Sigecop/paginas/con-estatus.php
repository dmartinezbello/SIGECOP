<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_especialidades = "SELECT AuCodEsp, TxNomEsp FROM especialidad ORDER BY TxNomEsp ASC";
$especialidades = mysql_query($query_especialidades, $conex) or die(mysql_error());
$row_especialidades = mysql_fetch_assoc($especialidades);
$totalRows_especialidades = mysql_num_rows($especialidades);
$Finicio=$_POST['ano'].'-01-01';
$Ffin=$_POST['ano'].'-12-31';
mysql_select_db($database_conex, $conex);
$query_proyectos = "SELECT proyecto.TxCodPro, proyecto.TxTitPro, proyecto.TxConPro, proyecto.TxEstPro, area.TxDesAre, area.TxTraAre, especialidad.TxNomEsp, linea.TxNomLin FROM proyecto, area, especialidad, linea WHERE proyecto.AuCodAre =  area.AuCodAre AND proyecto.txEstPro = '".$_POST['estatus']."' AND especialidad.AuCodEsp=area.AuCodEsp AND area.AuCodEsp='".$_POST['especialidad']."' AND area.TxTraAre='".$_POST['trayecto']."' AND linea.AuCodLin=area.NuCodLin AND proyecto.DtRegPro Between '$Finicio' AND '$Ffin'";
$proyectos = mysql_query($query_proyectos, $conex) or die(mysql_error());
$row_proyectos = mysql_fetch_assoc($proyectos);
$totalRows_proyectos = mysql_num_rows($proyectos);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Consulta proyectos por estatus</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
  <tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Lista de Proyectos por Estatus</h3></td>
  </tr>
  <tr>
    <td>
      <form name="form1" method="post" action="" class="icono">
        <fieldset>
          <legend><h2>Parametros de Consulta</h2></legend>
          <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
            <tr>
              <td width="50%"><label for="especialidad">Especialidad:</label>
                <select name="especialidad" class="textInput" id="especialidad" style="height:30px;">
                  <?php
do {  
?>
                  <option value="<?php echo $row_especialidades['AuCodEsp']?>"><?php echo $row_especialidades['TxNomEsp']?></option>
                  <?php
} while ($row_especialidades = mysql_fetch_assoc($especialidades));
  $rows = mysql_num_rows($especialidades);
  if($rows > 0) {
      mysql_data_seek($especialidades, 0);
	  $row_especialidades = mysql_fetch_assoc($especialidades);
  }
?>
              </select></td>
              <td width="20%"><label for="trayecto">Trayecto:</label>
                <select name="trayecto" class="textInput" id="trayecto" style="height:30px;">
                  <option value="1">Trayecto I</option>
                  <option value="2">Trayecto II</option>
                  <option value="3">Trayecto III</option>
                  <option value="4">Trayecto IV</option>
              </select></td>
              <td width="20%"><label for="estatus">Estatus</label>
                <select name="estatus" class="textInput" id="estatus">
                  <option value="p">En proceso</option>
                  <option value="e">En revision</option>
                  <option value="c">Condicionado</option>
                  <option value="a">Aprobado</option>
                  <option value="r">Reprobado</option>
              </select></td>
              <td width="10%"><label for="ano">A&ntilde;o:</label>
                <input name="ano" type="text" class="textInput" id="ano" value="<?php if (isset($_POST['ano'])) {echo htmlentities($_POST['ano']);} ?>"></td>
            </tr>
            <tr>
              <td colspan="4" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Buscar"></td>
              </tr>
            <tr>
              <td colspan="4" align="left"><?php if ($totalRows_proyectos == 0 && array_key_exists('enviar',$_POST)) { // Show if recordset empty ?>
  <p class="obligatorio">No se encontraron registros...</p>
  <?php } // Show if recordset empty ?></td>
            </tr>
          </table>
        </fieldset>
    </form>
      <?php if ($totalRows_proyectos > 0) { // Show if recordset not empty ?>
  <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
    <tr>
      <th colspan="6" align="right"><span>
      <span class="izq aparecer">Filtro:
	  <?php do {
		  if ($row_especialidades['AuCodEsp'] == $_POST['especialidad']){
		  echo 'Especialidad: '.$row_especialidades['TxNomEsp'];}
		  } while ($row_especialidades = mysql_fetch_assoc($especialidades));
		  if ($_POST['estatus']=="p"){ $est = "En proceso";}
		  if ($_POST['estatus']=="e"){ $est = "En revision";}
		  if ($_POST['estatus']=="c"){ $est = "Condicionado";}
		  if ($_POST['estatus']=="a"){ $est = "Aprobado";}
		  if ($_POST['estatus']=="r"){ $est = "Reprobado";}
		  ?>
	  <?php echo " / Trayecto ".$_POST['trayecto']." / Estatus: ".$est." / A&ntilde;o: ".$_POST['ano']." / registros obtenidos (".$totalRows_proyectos.")"; ?></span>
      <a href="#" onClick="window.print();" class="icono"><span class="icon-print">&nbsp;</span></a></span></th>
      </tr>
    <tr class="Tcabeza">
      <th width="50%" align="left">Datos de proyecto</th>
      <th width="25%" align="left">L&iacute;nea y &aacute;rea de investigaci&oacute;n</th>
      <th width="5%">Trayecto</th>
      <th width="10%" align="left">Especialidad</th>
      <th width="5%">Estatus</th>
      <th width="5%">Condici&oacute;n</th>
    </tr>
    <?php do { ?>
      <tr>
        <td width="50%" class="lineaInfPunta"><strong>C&oacute;digo:</strong>  <?php echo $row_proyectos['TxCodPro']; ?><br>
          <strong>T&iacute;tulo:</strong> <?php echo $row_proyectos['TxTitPro']; ?></td>
        <td width="25%" class="lineaInfPunta"><strong>Linea:</strong>  <?php echo $row_proyectos['TxNomLin']; ?><br>
          <strong>&Aacute;rea:</strong> <?php echo $row_proyectos['TxDesAre']; ?></td>
        <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_proyectos['TxTraAre']; ?></td>
        <td width="10%" class="lineaInfPunta"><?php echo $row_proyectos['TxNomEsp']; ?></td>
        <td width="5%" align="center" class="lineaInfPunta" <?php
						if($row_proyectos['TxEstPro']=="p"){echo "bgcolor='#666666'";}
						if($row_proyectos['TxEstPro']=="e"){echo "bgcolor='#0066ff'";}
						if($row_proyectos['TxEstPro']=="c"){echo "bgcolor='#ff9900'";}
						if($row_proyectos['TxEstPro']=="a"){echo "bgcolor='#00cc33'";}
						if($row_proyectos['TxEstPro']=="r"){echo "bgcolor='#ff0000'";}
				?>><?php 
				if($row_proyectos['TxEstPro']=="p"){echo "<span style='color:#FFF;'>En proceso</span>";}
				if($row_proyectos['TxEstPro']=="e"){echo "<span>En revisi&oacute;n</span>";}
				if($row_proyectos['TxEstPro']=="c"){echo "<span>Condicionado</span>";}
				if($row_proyectos['TxEstPro']=="a"){echo "<span>Aprobado</span>";}
				if($row_proyectos['TxEstPro']=="r"){echo "<span>Reprobado</span>";}
				?></td>
        <td width="5%" align="center" class="lineaInfPunta"
				<?php if ($row_proyectos['TxConPro']==0){echo 'bgcolor="#FF0000"';}
				      if ($row_proyectos['TxConPro']==1){echo 'bgcolor="#00cc33"';}
				?>><?php 
				if ($row_proyectos['TxConPro']==0){echo '<span style="color:#FFF;">Ejemplar no consignado</span>';}
				if ($row_proyectos['TxConPro']==1){echo '<span style="color:#FFF;">Ejemplar consignado</span>';}
				?></td>
      </tr>
      <?php } while ($row_proyectos = mysql_fetch_assoc($proyectos)); ?>
  </table>
  <?php } // Show if recordset not empty ?><br></td>
</tr>
  <tr>
    <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr valign="baseline"> </tr>
      <tr valign="baseline"> </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($especialidades);

mysql_free_result($proyectos);
?>
