<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_estudiantes = "SELECT especialidad.TxNomEsp, estudiante.TxCedEst, estudiante.TxApeEst, estudiante.TxNomEst, estudiante.TxMovilEst, estudiante.TxFijoEst, estudiante.TxDirEst, estudiante.TxMailEst FROM estudiante, especialidad WHERE especialidad.AuCodEsp=estudiante.NuCodEsp ORDER BY NuCodEsp, TxApeEst ASC";
$estudiantes = mysql_query($query_estudiantes, $conex) or die(mysql_error());
$row_estudiantes = mysql_fetch_assoc($estudiantes);
$totalRows_estudiantes = mysql_num_rows($estudiantes);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
  <tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Lista de Estudiantes</h3></td>
  </tr>
  <tr>
    <td>&nbsp;
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <td colspan="4" align="right" class="icono"><span class="icono"><a href="#" onclick="window.print();"><span class="icon-print">&nbsp;</span></a></span></td>
        </tr>
        <tr class="Tcabeza">
          <th width="30%" align="left">Estudiante</th>
          <th width="50%" align="left">Contacto</th>
          <th width="20%" align="left">Especialidad</th>
        </tr>
        <?php do { ?>
          <tr>
            <td class="lineaInfPunta"><?php echo $row_estudiantes['TxCedEst']; ?><br><?php echo $row_estudiantes['TxApeEst']; ?>, <?php echo $row_estudiantes['TxNomEst']; ?></td>
            <td width="40%" class="lineaInfPunta">Tel&eacute;fono Mov&iacute;l:  <?php echo $row_estudiantes['TxMovilEst']; ?><br>
              Tel&eacute;fono Fijo:  <?php echo $row_estudiantes['TxFijoEst']; ?><br>
              Correo Electtonico: <?php echo $row_estudiantes['TxMailEst']; ?><br>
              Direcci&oacute;n:  <?php echo $row_estudiantes['TxDirEst']; ?></td>
            <td class="lineaInfPunta"><?php echo $row_estudiantes['TxNomEsp']; ?></td>
          </tr>
          <?php } while ($row_estudiantes = mysql_fetch_assoc($estudiantes)); ?>
    </table><br></td>
</tr>
  <tr>
    <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr valign="baseline"> </tr>
      <tr valign="baseline"> </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($estudiantes);
?>
