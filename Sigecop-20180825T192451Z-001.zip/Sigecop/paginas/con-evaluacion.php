<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
//Declaraciones de variables
$Doc=array();
$Est=array();
$usu= "yenmi@gmail.com";
$dupli=0;
$max=0;
$vuelta=0.00;
//limpiar cadenas
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
//Verificar si el usuario activo puede evaluar
mysql_select_db($database_conex, $conex);
$query_usuario = "SELECT * FROM usuarios WHERE TxLogUsu = '".$usu."' AND NuNivelUsu = 2";
$usuario = mysql_query($query_usuario, $conex) or die(mysql_error());
$row_usuario = mysql_fetch_assoc($usuario);
$totalRows_usuario = mysql_num_rows($usuario);
$query_usuario = "SELECT docente.TxLogUsu FROM usuarios, jurado, docente WHERE usuarios.TxLogUsu = '".$usu."' AND NuNivelUsu = 2 AND jurado.TxCedDoc=docente.NuCedDoc AND docente.TxLogUsu=usuarios.TxLogUsu";
$usuario = mysql_query($query_usuario, $conex) or die(mysql_error());
$row_usuario = mysql_fetch_assoc($usuario);
$totalRows_usuario = mysql_num_rows($usuario);

// Evitar que un usuario pueda evualuar mas de una vez un trayecto en un proyecto
$colname_evitarDuplicado = "-1";
if (isset($_POST['TxTraEva'])) {
  $colname_evitarDuplicado = $_POST['TxTraEva'];
}
mysql_select_db($database_conex, $conex);
$query_evitarDuplicado = sprintf("SELECT TxLogUsu FROM evaluacion WHERE TxTraEva = %s  AND evaluacion.TxCodPro = '".$_POST['TxCodPro']."' AND evaluacion.TxLogUsu='".$usu."'", GetSQLValueString($colname_evitarDuplicado, "text"));
$evitarDuplicado = mysql_query($query_evitarDuplicado, $conex) or die(mysql_error());
$row_evitarDuplicado = mysql_fetch_assoc($evitarDuplicado);
$totalRows_evitarDuplicado = mysql_num_rows($evitarDuplicado);
// Validar que se les hayan colocado datos a los campos requeridos y que se haya indroducido un email en el campo email
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxTraEva']) && !empty($_POST['NuPunEva'])) {
	if (array_key_exists ('enviar', $_POST) &&  ($_POST['TxTraEva']==1 && $_POST['NuPunEva']<=15)  || ($_POST['TxTraEva']==2 && $_POST['NuPunEva']<=15) || ($_POST['TxTraEva']==3 && $_POST['NuPunEva']<=70)) {
		if($totalRows_evitarDuplicado==0){
			if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO evaluacion (AuCodEva, TxTraEva, NuPunEva, TxCodPro, TxLogUsu) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodEva'], "int"),
                       GetSQLValueString($_POST['TxTraEva'], "text"),
                       GetSQLValueString($_POST['NuPunEva'], "double"),
                       GetSQLValueString($_POST['TxCodPro'], "text"),
                       GetSQLValueString($_POST['TxLogUsu'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  header('Location: reg-evaluacion.php?codigo='.$_POST['TxCodPro'].'');
			}
		}else {$dupli=1;}
	}else{$max=1;}
}else{$error=1;}

$colname_identificarProyecto = "-1";
if (isset($_POST['codigo'])) {
  $colname_identificarProyecto = $_POST['codigo'];
}else{$colname_identificarProyecto = $_GET['codigo'];}
mysql_select_db($database_conex, $conex);
$query_identificarProyecto = sprintf("SELECT proyecto.TxTitPro, proyecto.TxBenPro, proyecto.DtRegPro, proyecto.TxConPro, proyecto.TxEstPro, institucion.TxNomIns, institucion.TxComIns, parroquia.TxDesPar, municipio.TxDesMun, estado.TxDesEst, proyecto.TxCodPro, area.TxDesAre, linea.TxNomLin, especialidad.TxNomEsp, area.AuCodAre FROM proyecto, institucion, parroquia, municipio, estado, area, linea, especialidad WHERE TxCodPro = %s AND institucion.AuCodIns = proyecto.AuNomIns AND parroquia.NuCodPar =  institucion.NuCodPar AND municipio.NuCodMun = parroquia.NuCodMun AND estado.NuCodEst = municipio.NuCodEst AND area.AuCodAre=proyecto.AuCodAre AND linea.AuCodLin=area.NuCodLin AND area.AuCodEsp = especialidad.AuCodEsp", GetSQLValueString($colname_identificarProyecto, "text"));
$identificarProyecto = mysql_query($query_identificarProyecto, $conex) or die(mysql_error());
$row_identificarProyecto = mysql_fetch_assoc($identificarProyecto);
$totalRows_identificarProyecto = mysql_num_rows($identificarProyecto);

$colname_DocRelacionados = "-1";
if (isset($_POST['codigo'])) {
  $colname_DocRelacionados = $_POST['codigo'];
  $proy=$_POST['codigo'];
}else{$colname_DocRelacionados = $_GET['codigo'];$proy=$_GET['codigo'];}
mysql_select_db($database_conex, $conex);
$query_DocRelacionados = sprintf("SELECT docente.NuCedDoc, docente.TxApeDoc, docente.TxNomDoc, docente.TxMovilDoc, docente.TxFIjoDoc, docente.TxEmailDoc, jurado.TxTipDoc, jurado.AuCodJur FROM jurado, docente WHERE TxCodPro = %s AND docente.NuCedDoc=jurado.TxCedDoc ORDER BY jurado.TxTipDoc DESC, docente.TxApeDoc ASC", GetSQLValueString($colname_DocRelacionados, "text"));
$DocRelacionados = mysql_query($query_DocRelacionados, $conex) or die(mysql_error());
$row_DocRelacionados = mysql_fetch_assoc($DocRelacionados);
$totalRows_DocRelacionados = mysql_num_rows($DocRelacionados);

mysql_select_db($database_conex, $conex);
$query_detalleGrupo = "SELECT  grupos.NuCodGru, estudiante.TxCedEst, estudiante.TxApeEst, estudiante.TxNomEst, estudiante.TxMovilEst, estudiante.TxFijoEst, estudiante.TxMailEst FROM  grupos, estudiante WHERE  TxCodPro = '".$proy."' AND estudiante.TxCedEst = grupos.TxCedest";
$detalleGrupo = mysql_query($query_detalleGrupo, $conex) or die(mysql_error());
$row_detalleGrupo = mysql_fetch_assoc($detalleGrupo);
$totalRows_detalleGrupo = mysql_num_rows($detalleGrupo);
// Obtener las evaluaciones
$colname_evaluacion = "-1";
if (isset($_POST['codigo'])) {
  $colname_evaluacion = $_POST['codigo'];
}else {$colname_evaluacion = $_GET['codigo'];}
mysql_select_db($database_conex, $conex);
$query_evaluacion = sprintf("SELECT evaluacion.AuCodEva, evaluacion.TxLogUsu, evaluacion.TxTraEva, evaluacion.NuPunEva, docente.NuCedDoc, docente.TxApeDoc, docente.TxNomDoc FROM evaluacion, docente WHERE TxCodPro = %s AND docente.TxLogUsu = evaluacion.TxLogUsu ORDER BY evaluacion.TxTraEva, docente.TxApeDoc ASC ", GetSQLValueString($colname_evaluacion, "text"));
$evaluacion = mysql_query($query_evaluacion, $conex) or die(mysql_error());
$row_evaluacion = mysql_fetch_assoc($evaluacion);
$totalRows_evaluacion = mysql_num_rows($evaluacion);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>registro evaluaciones</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
    <tr>
      <td align="center"><h3>Consulta  de Evaluaci&oacute;n</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td><br>
        <?php if ($totalRows_identificarProyecto == 0) { // Show if recordset empty ?>
          <form name="form1" method="post" action="">
            <table width="100%" border="0" cellspacing="7" cellpadding="0">
              <tr>
                <td width="10%">&nbsp;</td>
                <td><h2>Ubicar proyecto</h2></td>
                <td width="40%" valign="bottom">&nbsp;</td>
              </tr>
              <tr>
                <td width="10%">&nbsp;</td>
                <td width="50%"><label>C&oacute;digo de proyecto</label>
                  <input name="codigo" type="text" class="textInput" id="codigo"></td>
                <td width="40%" valign="bottom"><input name="buscar" type="submit" class="button" id="buscar" value="Buscar"></td>
              </tr>
            </table>
          </form>
          <?php } // Show if recordset empty ?>
        <?php if ($totalRows_usuario == 0) { // Show if recordset empty ?>
          <p class="obligatorio">Usted no tiene relacion con el proyecto que solicito, por eso no puede evaluarlo...</p>
          <?php } // Show if recordset empty ?>
        <?php if ($totalRows_identificarProyecto > 0) { // Show if recordset not empty ?>
          <?php if ($totalRows_usuario > 0) { // Show if recordset not empty ?>
            <table width="95%" border="0" align="center" cellpadding="5" cellspacing="0">
              <tr>
                <td colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td width="50%" align="center"
				<?php if($row_identificarProyecto['TxEstPro']=="p"){echo "bgcolor='#666666'";}
				      if($row_identificarProyecto['TxEstPro']=="e"){echo "bgcolor='#0066ff'";}
						if($row_identificarProyecto['TxEstPro']=="c"){echo "bgcolor='#ff9900'";}
						if($row_identificarProyecto['TxEstPro']=="a"){echo "bgcolor='#00cc33'";}
						if($row_identificarProyecto['TxEstPro']=="r"){echo "bgcolor='#ff0000'";}
				?>><?php 
				if($row_identificarProyecto['TxEstPro']=="p"){echo "<span class='estatus'>En proceso</span>";}
				if($row_identificarProyecto['TxEstPro']=="e"){echo "<span class='estatus'>En revisi&oacute;n</span>";}
				if($row_identificarProyecto['TxEstPro']=="c"){echo "<span class='estatus'>Condicionado</span>";}
				if($row_identificarProyecto['TxEstPro']=="a"){echo "<span class='estatus'>Aprobado</span>";}
				if($row_identificarProyecto['TxEstPro']=="r"){echo "<span class='estatus'>Reprobado</span>";}
				?></td>
                <td width="50%" align="center" 
            <?php if ($row_identificarProyecto['TxConPro']==0){echo 'bgcolor="#FF0000"';}
				      if ($row_identificarProyecto['TxConPro']==1){echo 'bgcolor="#00cc33"';}
				?>
            ><?php 
				if ($row_identificarProyecto['TxConPro']==0){echo '<span class="estatus">Ejemplar no consignado</span>';}
				if ($row_identificarProyecto['TxConPro']==1){echo '<span class="estatus">Ejemplar consignado</span>';}
				?></td>
              </tr>
              <?php do { ?>
                <tr>
                  <td colspan="2"><p style="font-size:22px;"><strong>C&Oacute;DIGO:</strong> <span class="obligatorio" style="font-size:22px;"><?php echo $row_identificarProyecto['TxCodPro']; ?></span></p>
                    <p><strong>Numero de beneficiarios: </strong><?php echo $row_identificarProyecto['TxBenPro']; ?></p>
                    <p><strong>Registrado el: </strong><?php echo $row_identificarProyecto['DtRegPro']; ?></p>
                    <p>&nbsp;</p>
                    <p><strong>T&iacute;tulo: </strong><?php echo $row_identificarProyecto['TxTitPro']; ?></p>
                    <p><strong>L&iacute;nea de investigaci&oacute;n y desarrollo:</strong> &Aacute;rea de desarrollo <strong><?php echo $row_identificarProyecto['TxDesAre']; ?></strong> dependiente de la l&iacute;nea de investigaci&oacute;n <strong><?php echo $row_identificarProyecto['TxNomLin']; ?></strong> de la especialidad <strong><?php echo $row_identificarProyecto['TxNomEsp']; ?></strong></p>
                    <p><strong>Contexto geogr&aacute;fico:</strong> <?php echo $row_identificarProyecto['TxNomIns']; ?> ubicado en la comunidad <?php echo $row_identificarProyecto['TxComIns']; ?> de la parroquia <?php echo $row_identificarProyecto['TxDesPar']; ?> municipio <?php echo $row_identificarProyecto['TxDesMun']; ?> del estado <?php echo $row_identificarProyecto['TxDesEst']; ?></p>

                    <br>
                    <p><strong>Estudiantes relacionados:</strong></p>
                    <table width="100%" border="0" cellpadding="10" cellspacing="1">
                      <tr class="Tcabeza">
                        <th width="35%" align="left">Estudiante</th>
                        <th width="25%" align="left">T&eacute;lefonos</th>
                        <th width="40%" align="left">Correo electronico</th>
                      </tr>
                      <?php 
				do {
					array_push($Est, $row_detalleGrupo['TxMailEst']);
				?>
                      <tr>
                        <td width="35%" class="lineaInfPunta"><?php echo $row_detalleGrupo['TxCedEst']; ?> <br>
                          <?php echo $row_detalleGrupo['TxApeEst']; ?>, <?php echo $row_detalleGrupo['TxNomEst']; ?></td>
                        <td width="25%" align="left" class="lineaInfPunta"><strong style="padding:0px 10px 0px 0px">Movil:</strong><?php echo $row_detalleGrupo['TxMovilEst']; ?><br>
                          <strong style="padding:0px 21px 0px 0px">Fijo:</strong><?php echo $row_detalleGrupo['TxFijoEst']; ?></td>
                        <td width="40%" class="lineaInfPunta"><?php echo $row_detalleGrupo['TxMailEst']; ?></td>
                      </tr>
                      <?php } while ($row_detalleGrupo = mysql_fetch_assoc($detalleGrupo)); 
				 //array_push($correoEst);
				  //print_r($Est);
				  ?>
                    </table>
                    <br>
                    <p><strong>Docentes relacionados:</strong></p>
                    <table width="100%" border="0" align="left" cellpadding="10" cellspacing="1">
                      <tr class="Tcabeza">
                        <th width="35%" align="left">Docente</th>
                        <th width="25%" align="left">Tel&eacute;fonos</th>
                        <th width="25%" align="left">Correo electronico</th>
                        <th width="15%" align="center">Clasificaci&oacute;n</th>
                      </tr>
                      <?php 
				
				do {
					array_push($Doc, $row_DocRelacionados['TxEmailDoc']); $vuelta++;
					?>
                      <tr>
                        <td width="35%" class="lineaInfPunta"><?php echo $row_DocRelacionados['NuCedDoc']; ?><br>
                          <?php echo $row_DocRelacionados['TxApeDoc']; ?>, <?php echo $row_DocRelacionados['TxNomDoc']; ?></td>
                        <td width="25%" align="left" class="lineaInfPunta"><strong style="padding:0px 10px 0px 0px">Movil:</strong> <?php echo $row_DocRelacionados['TxMovilDoc']; ?><br>
                          <strong style="padding:0px 23px 0px 0px">Fijo:</strong><?php echo $row_DocRelacionados['TxFIjoDoc']; ?></td>
                        <td width="25%" class="lineaInfPunta"><?php echo $row_DocRelacionados['TxEmailDoc']; ?></td>
                        <td width="15%" align="center" class="lineaInfPunta"><?php if ($row_DocRelacionados['TxTipDoc']=="t"){echo 'Tutor';}
						  															 if ($row_DocRelacionados['TxTipDoc']=="p"){echo 'Jurado principal';}
																					 if ($row_DocRelacionados['TxTipDoc']=="s"){echo 'Jurado suplente';}?></td>
                      </tr>
                      <?php } while ($row_DocRelacionados = mysql_fetch_assoc($DocRelacionados)); 
				  //print_r($Doc);
				  ?>
                    </table></td>
                </tr>
                <tr>
                  <td colspan="2"><h2>Tabla de evaluaciones</h2></td>
                </tr>
                <tr>
                  <td colspan="2"><?php if ($totalRows_evaluacion > 0) { // Show if recordset not empty ?>
  <table width="100%" border="0" cellpadding="10" cellspacing="1">
    <tr class="Tcabeza">
      <th width="35%" align="left">Docente</th>
      <th width="10%">Trimestre</th>
      <th width="35%">&nbsp;</th>
      <th width="15%">Puntaje</th>
    </tr>
    <?php 
			$trayectoI=0.00;
			$trayectoII=0.00;
			$trayectoIII=0.00;
			do {?>
      <tr>
        <td width="35%" class="lineaInfPunta"><?php echo $row_evaluacion['NuCedDoc']; ?><br>
          <?php echo $row_evaluacion['TxApeDoc']; ?>, <?php echo $row_evaluacion['TxNomDoc']; ?></td>
        <td width="10%" class="lineaInfPunta" align="center"><?php echo $row_evaluacion['TxTraEva']; ?></td>
        <td width="35%" class="lineaInfPunta" align="center">&nbsp;</td>
        <td width="15%" align="center" class="lineaInfPunta"><strong><?php echo $row_evaluacion['NuPunEva']; ?> %</strong></td>
      </tr>
      <?php 
			  if($row_evaluacion['TxTraEva']==1){$trayectoI = $trayectoI+$row_evaluacion['NuPunEva'];}
			  if($row_evaluacion['TxTraEva']==2){$trayectoII = $trayectoII+$row_evaluacion['NuPunEva'];}
			  if($row_evaluacion['TxTraEva']==3){$trayectoIII = $trayectoIII+$row_evaluacion['NuPunEva'];}
			  } while ($row_evaluacion = mysql_fetch_assoc($evaluacion)); ?>
  </table>
  <?php } // Show if recordset not empty ?>
<table width="100%" border="0" cellspacing="10" cellpadding="0">
                    <tr>
                        <td width="90%" align="right">Total Acumulado Trayecto I =</td>
                        <td width="10%" align="center"><?php echo number_format($trayectoI/$vuelta,2); ?> %</td>
                      </tr>
                      <tr>
                        <td width="90%" align="right">Total Acumulado Trayecto II =</td>
                        <td width="10%" align="center"><?php echo number_format($trayectoII/$vuelta,2); ?> %</td>
                      </tr>
                      <tr>
                        <td width="90%" align="right">Total Acumulado Trayecto III =</td>
                        <td width="10%" align="center"><?php echo number_format($trayectoIII/$vuelta,2); ?> %</td>
                      </tr>
                      <tr>
                        <td width="90%" align="right"><strong>Puntaje Alcanzado =</strong></td>
                        <td width="10%" align="center" class="obligatorio"><?php echo number_format(($trayectoI/$vuelta) + ($trayectoII/$vuelta) + ($trayectoIII/$vuelta),2); ?> %</td>
                      </tr>
                  </table></td>
                </tr>
                <?php } while ($row_identificarProyecto = mysql_fetch_assoc($identificarProyecto)); ?>
            </table>
            <?php } // Show if recordset not empty ?>
          <?php } // Show if recordset not empty ?>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($identificarProyecto);

mysql_free_result($DocRelacionados);

mysql_free_result($detalleGrupo);

mysql_free_result($evaluacion);

mysql_free_result($evitarDuplicado);

mysql_free_result($usuario);
?>
