<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_filtro = 20;
$pageNum_filtro = 0;
if (isset($_GET['pageNum_filtro'])) {
  $pageNum_filtro = $_GET['pageNum_filtro'];
}
$startRow_filtro = $pageNum_filtro * $maxRows_filtro;

mysql_select_db($database_conex, $conex);
$query_filtro = "SELECT proyecto.TxCodPro, proyecto.TxTitPro, proyecto.TxConPro, proyecto.TxEstPro, area.TxDesAre, area.TxTraAre, especialidad.TxNomEsp, linea.TxNomLin FROM proyecto, area, especialidad, linea WHERE TxTitPro LIKE '%".$_POST['busqueda']."%' AND TxCodPro LIKE 'PNFI%' AND proyecto.AuCodAre=area.AuCodAre AND area.AuCodEsp=especialidad.AuCodEsp AND linea.AuCodLin=area.NuCodLin ORDER BY TxTitPro ASC";
$query_limit_filtro = sprintf("%s LIMIT %d, %d", $query_filtro, $startRow_filtro, $maxRows_filtro);
$filtro = mysql_query($query_limit_filtro, $conex) or die(mysql_error());
$row_filtro = mysql_fetch_assoc($filtro);

if (isset($_GET['totalRows_filtro'])) {
  $totalRows_filtro = $_GET['totalRows_filtro'];
} else {
  $all_filtro = mysql_query($query_filtro);
  $totalRows_filtro = mysql_num_rows($all_filtro);
}
$totalPages_filtro = ceil($totalRows_filtro/$maxRows_filtro)-1;

$queryString_filtro = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_filtro") == false && 
        stristr($param, "totalRows_filtro") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_filtro = "&" . htmlentities(implode("&", $newParams));
  }
$queryString_filtro = sprintf("&totalRows_filtro=%d%s", $totalRows_filtro, $queryString_filtro);
}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Historial de Proyectos PNFI</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
<tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Historial de Proyectos PNFI</h3></td>
  </tr>
  <tr>
    <td class="Tcabeza">&nbsp;</td>
  </tr>
  <tr>
    <td><form name="form1" method="post" action="">
      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10" class="icono">
        <tr>
          <td width="50%"><h2>Especificaciones de b&uacute;squeda</h2></td>
          <td width="50%" align="right" valign="bottom"><span class="colorTextRojo">Puede mejorar su b&uacute;squeda utilizando el caractere <strong>%</strong> delante o despues de cada palabra para obtener resultados mas certeros</span></td>
        </tr>
        <tr>
          <td colspan="2"><input name="busqueda" type="text" class="textInput" id="busqueda"></td>
          </tr>
        <tr>
          <td width="50%" class="obligatorio"><?php if ($totalRows_filtro == 0) { // Show if recordset empty ?>
              No se encontraron resultados...
  <?php } // Show if recordset empty ?></td>
          <td width="40%" align="right"><input name="Buscar" type="submit" class="button" id="Buscar" value="Buscar"></td>
        </tr>
      </table>
    </form>
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <th colspan="6" align="left"><span>
            <span class="izq aparecer">Fecha de consulta:<strong>
              <?php
          $dias = array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","S&aacute;bado");
			 $meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
			 echo $dias[date('w')]." ".date('d')." de ".$meses[date('n')-1]. " del ".date('Y') ;
			 ?>
              </strong> Filtro: <?php echo $_POST['busqueda']; ?> registros encontrados(<?php echo $totalRows_filtro; ?>)</span>
            <a href="#" onClick="window.print();" class="icono"><span class="icon-print der">&nbsp;</span></a>
          </span></th>
        </tr>
        <?php if ($totalRows_filtro > 0) { // Show if recordset not empty ?>
          <?php if ($totalRows_filtro > 0) { // Show if recordset not empty ?>
            <tr class="Tcabeza">
              <th width="50%" align="left">Datos de proyecto</th>
              <th width="25%" align="left">L&iacute;nea y &aacute;rea de investigaci&oacute;n</th>
              <th width="5%">Trayecto</th>
              <th width="10%" align="left">Especialidad</th>
              <th width="5%">Estatus</th>
              <th width="5%">Condici&oacute;n</th>
            </tr>
            <?php } // Show if recordset not empty ?>
          <?php } // Show if recordset not empty ?>
<?php do { ?>
      <tr>
        <td width="50%" class="lineaInfPunta"><strong>C&oacute;digo:</strong>
          <?php echo $row_filtro['TxCodPro']; ?><br>
          <strong>T&iacute;tulo:</strong>
          <?php echo $row_filtro['TxTitPro']; ?></td>
        <td width="25%" class="lineaInfPunta"><strong>Linea:</strong>
          <?php echo $row_filtro['TxNomLin']; ?><br>
          <strong>&Aacute;rea:</strong>
          <?php echo $row_filtro['TxDesAre']; ?></td>
        <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_filtro['TxTraAre']; ?></td>
        <td width="10%" class="lineaInfPunta"><?php echo $row_filtro['TxNomEsp']; ?></td>
        <td width="5%" align="center" class="lineaInfPunta" <?php
						if($row_filtro['TxEstPro']=="p"){echo "bgcolor='#666666'";}
						if($row_filtro['TxEstPro']=="e"){echo "bgcolor='#0066ff'";}
						if($row_filtro['TxEstPro']=="c"){echo "bgcolor='#ff9900'";}
						if($row_filtro['TxEstPro']=="a"){echo "bgcolor='#00cc33'";}
						if($row_filtro['TxEstPro']=="r"){echo "bgcolor='#ff0000'";}
				?>><?php 
				if($row_filtro['TxEstPro']=="p"){echo "<span style='color:#FFF;'>En proceso</span>";}
				if($row_filtro['TxEstPro']=="e"){echo "<span>En revisi&oacute;n</span>";}
				if($row_filtro['TxEstPro']=="c"){echo "<span>Condicionado</span>";}
				if($row_filtro['TxEstPro']=="a"){echo "<span>Aprobado</span>";}
				if($row_filtro['TxEstPro']=="r"){echo "<span>Reprobado</span>";}
				?></td>
        <td width="5%" align="center" class="lineaInfPunta"
				<?php if ($row_proyectos['TxConPro']==0){echo 'bgcolor="#FF0000"';}
				      if ($row_proyectos['TxConPro']==1){echo 'bgcolor="#00cc33"';}
				?>><?php 
				if ($row_filtro['TxConPro']==0){echo '<span style="color:#FFF;">Ejemplar no consignado</span>';}
				if ($row_filtro['TxConPro']==1){echo '<span style="color:#FFF;">Ejemplar consignado</span>';}
				?></td>
      </tr>
      <?php } while ($row_filtro = mysql_fetch_assoc($filtro)); ?>
  </table>
    <table border="0" align="center">
      <tr>
        <td><?php if ($pageNum_filtro > 0) { // Show if not first page ?>
            <a href="<?php printf("%s?pageNum_filtro=%d%s", $currentPage, 0, $queryString_filtro); ?>">Primer registro</a>
            <?php } // Show if not first page ?></td>
        <td><?php if ($pageNum_filtro > 0) { // Show if not first page ?>
            <a href="<?php printf("%s?pageNum_filtro=%d%s", $currentPage, max(0, $pageNum_filtro - 1), $queryString_filtro); ?>">Anterior</a>
            <?php } // Show if not first page ?></td>
        <td><?php if ($pageNum_filtro < $totalPages_filtro) { // Show if not last page ?>
            <a href="<?php printf("%s?pageNum_filtro=%d%s", $currentPage, min($totalPages_filtro, $pageNum_filtro + 1), $queryString_filtro); ?>">Siguiente</a>
            <?php } // Show if not last page ?></td>
        <td><?php if ($pageNum_filtro < $totalPages_filtro) { // Show if not last page ?>
            <a href="<?php printf("%s?pageNum_filtro=%d%s", $currentPage, $totalPages_filtro, $queryString_filtro); ?>">Ultimo registro</a>
            <?php } // Show if not last page ?></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td class="Tcabeza">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($filtro);
?>
