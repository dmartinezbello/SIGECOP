<?php require_once('../Connections/conex.php'); ?>
<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_linea = "SELECT * FROM linea ORDER BY TxNomLin ASC";
$linea = mysql_query($query_linea, $conex) or die(mysql_error());
$row_linea = mysql_fetch_assoc($linea);
$totalRows_linea = mysql_num_rows($linea);


?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%">
  <tr>
    <td align="center" class="oculto aparecer"><img src="../img/CabeceraSigecop.PNG" width="879" height="91" alt="cabecera"></td>
  </tr>
  <tr>
    <td align="center"><h3>Lista de L&iacute;neas de Investigaci&oacute;n</h3></td>
  </tr>
  <tr>
    <td>&nbsp;
      <table width="95%" border="0" cellpadding="10" cellspacing="0">
        <tr>
          <td colspan="2" align="right" class="icono"><span class="icono"><a href="#" onclick="window.print();"><span class="icon-print">&nbsp;</span></a></span></td>
        </tr>
        <tr>
          <th colspan="2" align="left" class="Tcabeza">L&iacute;nea de investigaci&oacute;n</th>
        </tr>
        <?php do { ?>
          <tr>
            <th colspan="2" align="left" class="obligatorio"><?php echo $row_linea['TxNomLin']; ?></th>
          </tr>
          <tr>
            <td width="20" align="right" class="lineaInfPunta">&nbsp;</td>
            <td width="80%" class="lineaInfPunta">
            <?php mysql_select_db($database_conex, $conex);
$query_areas = "SELECT area.AuCodAre, area.TxDesAre, area.TxTraAre, especialidad.TxNomEsp FROM area, especialidad WHERE NuCodLin = '".$row_linea['AuCodLin']."' AND especialidad.AuCodEsp=area.AuCodEsp ORDER BY TxDesAre, AuCodAre ASC";
$areas = mysql_query($query_areas, $conex) or die(mysql_error());
$row_areas = mysql_fetch_assoc($areas);
$totalRows_areas = mysql_num_rows($areas);?>
            <?php if ($totalRows_areas > 0) { // Show if recordset not empty ?>
  <table width="100%" border="0" cellpadding="10" cellspacing="0">
    <tr>
      <th width="60" align="left">Area de desarrollo</th>
      <th width="5%">Trayecto</th>
      <th width="35%" align="left">Especialidad</th>
    </tr>
    <?php do { ?>
      <tr>
        <td width="60"><?php echo $row_areas['TxDesAre']; ?></td>
        <td width="5%" align="center"><?php echo $row_areas['TxTraAre']; ?></td>
        <td><?php echo $row_areas['TxNomEsp']; ?></td>
      </tr>
      <?php } while ($row_areas = mysql_fetch_assoc($areas)); ?>
  </table>
  <?php } // Show if recordset not empty ?>            </td>
          </tr>
          <?php } while ($row_linea = mysql_fetch_assoc($linea)); ?>
    </table><br></td>
</tr>
  <tr>
    <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr valign="baseline"> </tr>
      <tr valign="baseline"> </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($linea);

mysql_free_result($areas);
?>
