<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  <title>.:SIGECOP:.</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td colspan="2" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><h1>Contactos</h1></td>
  </tr>
  <tr>
    <td width="10%"><img src="../fotos/Contacto.PNG" alt="hombrecillo" width="148" height="221" class="der"></td>
    <td width="90%" align="center" valign="middle"><table width="100%" border="0" cellspacing="10" cellpadding="0">
      <tr>
        <td width="20%" valign="middle"><strong>Desarrollador:</strong></td>
        <td width="40%"><p>Daniel Martinez
        </p></td>
        <td width="40%"><strong>Correo Electronico: </strong>
          <a href="mailto:DMartinezBello@gmail.com">MartinezBello@gmail.com</a></td>
      </tr>
      <tr>
        <td width="20%"><strong>Soporte:</strong></td>
        <td width="40%"><p>Francismar reyes<br>
        </p></td>
        <td width="40%"><strong>Correo Electronico: </strong>
          <a href="mail:werlyne@gmail.com">werlyne@gmail.com</a></td>
      </tr>
      <tr>
        <td width="20%">&nbsp;</td>
        <td width="40%"><p>Elysneldi Lezama<br>
        </p></td>
        <td width="40%"><strong>Correo Electronico: </strong>
          <a href="mail:Lezama@gmail.com">Lezama@gmail.com</a></td>
      </tr>
      <tr>
        <td height="20" colspan="3" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3" align="center"><p style="text-align:center;"><strong>Sistema de gesti&oacute;n y Control de Proyectos para la Universidad Politecnica Territorial del Norte de Monagas &quot;Ludovico Silva&quot; sede Punta de Mata.</strong></p>
          <p style="text-align:center;">&nbsp;</p>
          <p style="text-align:center;"><strong>Versi&oacute;n: 1.0</strong></p>
          <p style="text-align:center;"><strong>Fecha de desarrollo:</strong> Julio de 2013</p>
          <p style="text-align:center;">Producto desarrollo el lenguaje de Programaci&oacute;n <strong>PHP</strong></p>
          <p style="text-align:center;" ><strong>Recursos:</strong> HTML, CSS, JavaScript, Ajax</p></td>
        </tr>
    </table>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="90%">&nbsp;</td>
  </tr>
</table>
</body>
</html>