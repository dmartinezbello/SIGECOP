<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_ObtenerPass = "-1";
if (isset($_POST['usuario'])) {
  $colname_ObtenerPass = $_POST['usuario'];
}
mysql_select_db($database_conex, $conex);
$query_ObtenerPass = sprintf("SELECT * FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_ObtenerPass, "text"));
$ObtenerPass = mysql_query($query_ObtenerPass, $conex) or die(mysql_error());
$row_ObtenerPass = mysql_fetch_assoc($ObtenerPass);
$totalRows_ObtenerPass = mysql_num_rows($ObtenerPass);

$negado=0;
if (array_key_exists('enviar', $_POST) && $row_ObtenerPass['TxPasUsu'] == $_POST['passViejo']){
	mysql_select_db($database_conex, $conex);
	 $sSQL="UPDATE sigecop.usuarios SET TxPasUsu = '".$_POST['passNuevo']."' WHERE usuarios.TxLogUsu = '".$_POST['usuario']."'"; 
     $Result2 = mysql_query($sSQL, $conex) or die(mysql_error()); 
     echo "<script language='JavaScript'> alert('El proceso de actualizaci�n de clave de acceso fue realizado con exito');</script>";
     $_POST = array();
	}else {$negado=1;}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>cambio de clave</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="100%">
  <tr>
    <td align="center"><h3>Cambio de Clave</h3></td>
  </tr>
  <tr>
    <td class="Tcabeza">&nbsp;</td>
  </tr>
  <tr>
    <td><form name="form1" method="post" action="">
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <td colspan="2"><h2>Datos de usuario</h2> 
            <p>
              <a href="olvido-clave.php" target="mainFrame" class="der" style="display: inline-table;">&iquest;Olvido su contrase&ntilde;a?</a></p>
              <?php if ($_POST && $negado == 1){ echo "<p class='obligatorio'>El proceso de cambio de clave fall�, no concuerda el nombre de usuario y la contrasena actual</p>";} ?>
              </td>
          </tr>
        <tr>
          <td width="50%"><label for="usuario">Nombre de Usuario:</label>
            <input name="usuario" type="text" class="textInput" id="usuario"></td>
          <td width="50%">&nbsp;</td>
        </tr>
        <tr>
          <td width="50%"><label for="passViejo">Contrasena actual:</label>
            <input name="passViejo" type="password" class="textInput" id="passViejo"></td>
          <td width="50%"><label for="passNuevo">Contrasena Nueva:</label>
            <input name="passNuevo" type="password" class="textInput" id="passNuevo"></td>
        </tr>
        <tr>
          <td width="50%">&nbsp;</td>
          <td width="50%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Actualizar"></td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td class="Tcabeza">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($ObtenerPass);
?>
