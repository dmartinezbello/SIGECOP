<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
//Obtener Trayecto del area de desarrollo

$colname_trayecto = "-1";
if (isset($_POST['AuCodAre'])) {
  $colname_trayecto = $_POST['AuCodAre'];
}
mysql_select_db($database_conex, $conex);
$query_trayecto = sprintf("SELECT TxTraAre FROM area WHERE AuCodAre = %s", GetSQLValueString($colname_trayecto, "int"));
$trayecto = mysql_query($query_trayecto, $conex) or die(mysql_error());
$row_trayecto = mysql_fetch_assoc($trayecto);
$totalRows_trayecto = mysql_num_rows($trayecto);

//Obtener siglas de la especialidad

$esp=$row_obtenerSigla['TxSigEsp']; // obtener las siglas de la especialidad seleccionada en el combo especialidad
$ano=date('Y');// Declarar el ano actual de registro del proyecto
$colname_obtenerSigla = "-1";
if (isset($_POST['especialidad'])) {
  $colname_obtenerSigla = $_POST['especialidad'];
}
mysql_select_db($database_conex, $conex);
$query_proyecto = "SELECT *  FROM  `proyecto`  WHERE  `TxCodPro` LIKE CONVERT( _utf8 '%".$esp.$ano."%' USING latin1 )  COLLATE latin1_spanish_ci";
$proyecto = mysql_query($query_proyecto, $conex) or die(mysql_error());
$row_proyecto = mysql_fetch_assoc($proyecto);
$totalRows_proyecto = mysql_num_rows($proyecto);


//Generar el codigo que se le va asignar al proyecto
$trayect='T'.$row_trayecto['TxTraAre'];
$numero=$totalRows_proyecto+1;
$codigo=$esp.$ano.$trayect.' - '.str_pad($numero, 4, 0, STR_PAD);
$_POST['TxConPro']=0;

// Validar que se les hayan colocado datos a los campos requeridos y que se haya indroducido un email en el campo email
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxTitPro'])) {
if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = "UPDATE proyecto SET TxTitPro = '".$_POST['TxTitPro']."', TxEstPro ='".$_POST['TxEstPro']."', AuNomIns = ".$_POST['AuNomIns'].", AuCodAre = ".$_POST['AuCodAre']." WHERE TxCodPro = '".$_POST['codigo']."'";
  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
  header ('Location: reg-est-tut-pro.php?proyecto='.$_POST['codigo']);}
}else {$error=1;}
mysql_select_db($database_conex, $conex);
$query_especialidad = "SELECT * FROM especialidad ORDER BY TxNomEsp ASC";
$especialidad = mysql_query($query_especialidad, $conex) or die(mysql_error());
$row_especialidad = mysql_fetch_assoc($especialidad);
$totalRows_especialidad = mysql_num_rows($especialidad);

mysql_select_db($database_conex, $conex);
$query_estado = "SELECT * FROM estado ORDER BY TxDesEst ASC";
$estado = mysql_query($query_estado, $conex) or die(mysql_error());
$row_estado = mysql_fetch_assoc($estado);
$totalRows_estado = mysql_num_rows($estado);

$colname_obtenerProyecto = "-1";
if (isset($_POST['codigo'])) {
  $colname_obtenerProyecto = $_POST['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerProyecto = sprintf("SELECT area.TxDesAre, proyecto.TxCodPro, proyecto.TxTitPro, proyecto.TxConPro, proyecto.TxEstPro, especialidad.TxNomEsp, linea.TxNomLin, institucion.TxNomIns, institucion.TxComIns, parroquia.TxDesPar, municipio.TxDesMun, estado.TxDesEst, area.AuCodAre, proyecto.AuNomIns FROM proyecto, area, especialidad, linea, institucion, parroquia, municipio, estado WHERE TxCodPro = %s AND area.AuCodAre=proyecto.AuCodAre  AND especialidad.AuCodEsp=area.AuCodEsp AND linea.AuCodLin=area.NuCodLin AND proyecto.AuNomIns=institucion.AuCodIns AND institucion.NuCodPar = parroquia.NuCodPar AND parroquia.NuCodMun=municipio.NuCodMun AND municipio.NuCodEst=estado.NuCodEst", GetSQLValueString($colname_obtenerProyecto, "text"));
$obtenerProyecto = mysql_query($query_obtenerProyecto, $conex) or die(mysql_error());
$row_obtenerProyecto = mysql_fetch_assoc($obtenerProyecto);
$totalRows_obtenerProyecto = mysql_num_rows($obtenerProyecto);

?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>registrar de proyecto</title>
  <script type="text/javascript" src="../js/ajax.js"></script>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>
<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Registrar Proyecto</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td><?php if ($totalRows_obtenerProyecto == 0) { // Show if recordset empty ?>
  <form name="form2" method="post" action="">
    <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
      <tr>
        <td><h2>Datos del proyecto</h2></td>
        <td>&nbsp;</td>
        </tr>
      <tr>
        <td colspan="2"><label for="codigo">C&oacute;digo de proyecto:</label>
          <input name="codigo" type="text" class="textInput" id="codigo"></td>
        </tr>
      <tr>
        <td colspan="2" align="right"><input name="buscar" type="submit" class="button" id="buscar" value="Buscar"></td>
        </tr>
      </table>
  </form>
  <?php } // Show if recordset empty ?>
        <?php if ($totalRows_obtenerProyecto > 0) { // Show if recordset not empty ?>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
              <?php if (array_key_exists ('enviar', $_POST) && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
              <tr valign="baseline">
                <td colspan="3" nowrap><h2>Datos del proyecto</h2></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="left" nowrap>&nbsp;</td>
                <td width="25%"><label for="TxConPro">Condicion:</label>
                  <select name="TxConPro" class="textInput" id="TxConPro"  style="height:31px;">
                    <option value="0">Ejemplar no consignado</option>
                    <option value="1">Ejemplar consignado</option>
                </select></td>
                <td width="25%"><label>Estatus del Proyecto:</label>
                  <select name="TxEstPro" class="textInput" id="TxEstPro" style="height:31px;">
                    <option value="<?php echo $row_obtenerProyecto['TxEstPro']; ?>">
					<?php 
						if($row_obtenerProyecto['TxEstPro']=="p"){echo "En proceso";}
						if($row_obtenerProyecto['TxEstPro']=="e"){echo "En revisi&oacute;n";}
						if($row_obtenerProyecto['TxEstPro']=="c"){echo "Condicionado";}
						if($row_obtenerProyecto['TxEstPro']=="a"){echo "Aprobado";}
						if($row_obtenerProyecto['TxEstPro']=="r"){echo "Reprobado";}
					?>
                    </option>
                    <option value="p">En proceso</option>
                    <option value="e">En revision</option>
                    <option value="c">Condicionado</option>
                  </select></td>
              </tr>
              <tr valign="baseline">
                <td colspan="3" nowrap><label>T&iacute;tulo:
                  <?php if (array_key_exists ('enviar', $_POST) && $_POST['TxTitPro'] == "") { echo $icono;}?>
                </label>
                  <textarea name="TxTitPro" cols="32" rows="3" class="anchoFull"><?php echo $row_obtenerProyecto['TxTitPro']; ?></textarea></td>
              </tr>
              <tr valign="baseline">
                <td colspan="3" nowrap>
                <h2>L&iacute;nea de investigaci&oacute;n y desarrollo</h2>
                <div style="max-width: 512px; width:140px; word-wrap: break-word;"><?php echo"<p> Actualmente el proyecto esta suscrito a la  Especialiadad <strong>".$row_obtenerProyecto['TxNomEsp']."</strong>,  </p><p>L�nea de investigaci�n <strong>".$row_obtenerProyecto['TxNomLin']."</strong> y  area de desarrollo <strong>".$row_obtenerProyecto['TxDesAre']."</strong> </p>"; ?></div>
                </td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><label for="especialidad">Especialidad:
                  <?php if (array_key_exists ('enviar', $_POST) && $_POST['AuCodAre'] == "") { echo $icono;}?>
                </label>
                  <select name="especialidad" class="textInput" id="especialidad" onChange="carga_linea_investigacion(this.value)">
                    <option value="0">Seleccione una opcion</option>
                    <?php
do {  
?>
                    <option value="<?php echo $row_especialidad['AuCodEsp']?>"><?php echo $row_especialidad['TxNomEsp']?></option>
                    <?php
} while ($row_especialidad = mysql_fetch_assoc($especialidad));
  $rows = mysql_num_rows($especialidad);
  if($rows > 0) {
      mysql_data_seek($especialidad, 0);
	  $row_especialidad = mysql_fetch_assoc($especialidad);
  }
?>
                  </select></td>
                <td colspan="2"><div id="linea">
                  <label for="AuCodAre"></label>
                  <input name="AuCodAre" type="hidden" id="AuCodAre" value="<?php echo $row_obtenerProyecto['AuCodAre']; ?>">
                </div></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="left" nowrap><div id="area"></div></td>
                <td colspan="2">&nbsp;</td>
              </tr>
              <tr valign="baseline">
                <td colspan="3" align="left" nowrap>
                <h2>Contexto geogr&aacute;fico</h2>
                <p style="max-width: 512px; width:140px; word-wrap: break-word;"><strong>El contexto geografico suscrito actualmente es:</strong> Estado <?php echo $row_obtenerProyecto['TxDesEst']; ?>, Municipio <?php echo $row_obtenerProyecto['TxDesMun']; ?>, </p>
                <p style="max-width: 512px; width:140px; word-wrap: break-word;">Parroquia <?php echo $row_obtenerProyecto['TxDesPar']; ?>, Comunidad <?php echo $row_obtenerProyecto['TxComIns']; ?>, Instituci&oacute;n <?php echo $row_obtenerProyecto['TxNomIns']; ?></p></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" nowrap><label>Estado:
                  <?php if (array_key_exists ('enviar', $_POST) && $_POST['AuNomIns'] == "") { echo $icono;}?>
                </label>
                  <select name="cont" class="textInput" id="cont" onChange="load(this.value)">
                    <option value="0">Seleccione una opci&oacute;n</option>
                    <?php
do {  
?>
                    <option value="<?php echo $row_estado['NuCodEst']?>"><?php echo $row_estado['TxDesEst']?></option>
                    <?php
} while ($row_estado = mysql_fetch_assoc($estado));
  $rows = mysql_num_rows($estado);
  if($rows > 0) {
      mysql_data_seek($estado, 0);
	  $row_estado = mysql_fetch_assoc($estado);
  }
?>
                  </select></td>
                <td colspan="2"><div id="myDiv">
                  <label for="AuNomIns"></label>
                  <input type="hidden" name="AuNomIns" id="AuNomIns" value="<?php echo $row_obtenerProyecto['AuNomIns']; ?>">
                </div></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><div id="parroquias"></div></td>
                <td colspan="2"><div id="comunidad"></div></td>
              </tr>
              <tr valign="baseline">
                <td colspan="3" align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Modificar">
                  <input name="Restablecer" type="reset" class="button der" value="Restablecer">
                  <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" />
                &nbsp;</td>
              </tr>
            </table>
            <input type="hidden" name="DtRegPro" value="">
            <label for="codigo"></label>
            <input type="hidden" name="codigo" id="codigo" value="<?php echo $_POST['codigo'];?>">
            <input type="hidden" name="MM_update" value="form1">
        </form>
          <?php } // Show if recordset not empty ?></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($especialidad);

mysql_free_result($estado);

mysql_free_result($obtenerProyecto);

mysql_free_result($trayecto);

mysql_free_result($proyecto);
?>