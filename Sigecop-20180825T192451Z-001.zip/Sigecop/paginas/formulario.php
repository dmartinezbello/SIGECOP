<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  <title>.:SIGECOP:.</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"><h3>Pagina Principal</h3></td>
    </tr>
  </table>
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td height="5" class="Tcabeza">cabecera de formulario</td>
    </tr>
    <tr>
      <td height="15" style="border:1px solid #ececec;">cuerpo de formulario
        <table width="70%" border="0" align="center" cellpadding="0" cellspacing="10">
          <tr>
            <td colspan="3"><span class="obligatorio">Debe completar los campos obligatorios se&ntilde;alados con el icono &quot; <span class="icon-obligatorio">&nbsp;&nbsp;&nbsp;&nbsp;</span> &quot;</span></td>
          </tr>
          <tr>
            <td><h2>Datos personales</h2></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="48%"><label><span class="icon-obligatorio der">&nbsp;</span> Nombres</label>
              <input name="textfield" type="text" class="anchoFull" id="textfield"></td>
            <td>&nbsp;</td>
            <td width="48%"><label for="textfield2">Apellidos</label>
              <input name="textfield2" type="text" class="anchoFull" id="textfield2"></td>
          </tr>
          <tr>
            <td><label for="textfield3">Cedula</label>
              <input name="textfield3" type="text" class="anchoFull" id="textfield3"></td>
            <td>&nbsp;</td>
            <td><label for="textfield4">Telefono</label>
              <input name="textfield4" type="text" class="anchoFull" id="textfield4"></td>
          </tr>
          <tr>
            <td colspan="3"><form name="form1" method="post" action="">
                <label>Comentarios</label>
                <textarea name="textfield5" rows="5" id="textfield5"></textarea>
              </form></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="button" type="submit" class="button der" id="button" value="Registrar"></td>
          </tr>
      </table></td>
    </tr>
    <tr>
      <td height="5" class="Tcabeza">pie de formulario</td>
    </tr>
  </table>
</body>
</html>