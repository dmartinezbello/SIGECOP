<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
<title>Sigecop - Lateral izquierdo</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="15" style="border:1px solid #ececec;"><form name="form1" method="post" action="">
        <table width="100%" align="center" cellpadding="0" cellspacing="10">
          <tr>
            <td><h2>Iniciar sesi&oacute;n</h2></td>
          </tr>
          <tr>
            <td width="48%"><label><span class="icon-obligatorio der">&nbsp;&nbsp;&nbsp;</span> Usuario:</label>
              <input name="usuario" type="text" class="anchoFull" id="usuario"></td>
          </tr>
          <tr>
            <td><label for="textfield3">Contrase&ntilde;a:<span class="icon-obligatorio der">&nbsp;&nbsp;&nbsp;</span></label>
              <input name="pass" type="text" class="anchoFull" id="pass"></td>
          </tr>
          <tr>
            <td><input name="button" type="submit" class="button der" id="button" value="Registrar"></td>
          </tr>
          <tr>
            <td align="center"></td>
          </tr>
        </table>
      </form></td>
  </tr>
  <tr>
    <td height="5" class="Tcabeza">&nbsp;</td>
  </tr>
</table>
</body>
</html>
