<?php
$icono= "<span class='icon-obligatorio der'>&nbsp;</span>";
$iconoAzul= "<span class='icon-obligaAzul der'>&nbsp;</span>";
$iconoVerde= "<span class='icon-obligaVerde der'>&nbsp;</span>";
$vacio="No se puede continuar, No se encontraron registros asociados al codigo que ingreso";
$incompleto= "<span class='obligatorio'>Es necesario que ingrese los datos minimos  requeridos. Por favor, complete los campos que se indican con el caracter <span class='icon-obligatorio'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";
$duplicado = "<span class='obligatorio'>No se completo el proceso de registro porque ya existe un registro identico. Por favor, vuelva a intentar introduciendo datos diferentes donde esta el icono <span class='icon-obligaAzul'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";
$dupUsuario = "<span class='obligatorio'>El correo electronico ingresado ya esta registrado, por favor indique un correo electronico nuevo </span><span class='icon-obligaVerde'>&nbsp;&nbsp;&nbsp;&nbsp;</span></span>";
$diferencia ="No se puede completar el proceso de registro porque la cantidad que pretende recibir supera lo esperado por el item para esta solicitud";
?>