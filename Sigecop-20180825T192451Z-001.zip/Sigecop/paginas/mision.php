<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  <title>.:SIGECOP:.</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td colspan="2" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><h1>Misi&oacute;n</h1></td>
  </tr>
  <tr>
    <td width="90%" rowspan="2"><p>Contribuir a la  formaci&oacute;n de profesionales de car&aacute;cter humanista y lograr la participaci&oacute;n  decidida y protag&oacute;nica de los docentes y recurso humano del Instituto, en la prevenci&oacute;n y soluci&oacute;n de las  problem&aacute;ticas presentadas y brindar la mayor eficiencia en las l&iacute;neas de  investigaci&oacute;n; a su vez poseer un ciudadano capaz, preocupado y dispuesto a la  b&uacute;squeda del mayor c&uacute;mulo de felicidad.</p></td>
    <td width="10%"><img src="../fotos/manonplane-n.png" alt="hombrecillo" width="177" height="169" class="der"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>