<?php
include '../Connections/conex.php';
 
$q=$_POST['q'];
$res=mysql_query("select * from municipio where NuCodEst=".$q."",$conex);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
</head>
<body>
<label>Municipio:</label>
<select id="estado" class="textInput" onChange="load2(this.value)">
<option value="">Seleccione una opci&oacute;n</option> 
 
<?php while($fila=mysql_fetch_array($res)){ ?>
<option value="<?php echo $fila['NuCodMun']; ?>"><?php echo $fila['TxDesMun']; ?></option>
<?php } ?>
</select>
</body>
</html>
