<?php require_once('../Connections/conex.php'); ?>
<?php
$nuevoPass = rand(1000000, 10000000);
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_obtenerUsuario = "-1";
if (isset($_POST['usuario'])) {
  $colname_obtenerUsuario = $_POST['usuario'];
}
$negado=0;
mysql_select_db($database_conex, $conex);
$query_obtenerUsuario = sprintf("SELECT * FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_obtenerUsuario, "text"));
$obtenerUsuario = mysql_query($query_obtenerUsuario, $conex) or die(mysql_error());
$row_obtenerUsuario = mysql_fetch_assoc($obtenerUsuario);
$totalRows_obtenerUsuario = mysql_num_rows($obtenerUsuario);

if (array_key_exists('enviar', $_POST) && $row_obtenerUsuario['TxLogUsu'] == $_POST['usuario']){
	mysql_select_db($database_conex, $conex);
	 $sSQL="UPDATE sigecop.usuarios SET TxPasUsu = '".$nuevoPass."' WHERE usuarios.TxLogUsu = '".$_POST['usuario']."'"; 
     $Result2 = mysql_query($sSQL, $conex) or die(mysql_error());
	 include('../phpmailer/correo-olvido-clave.php');
  confirmarRegistro($_POST['usuario'], $nuevoPass);
     echo "<script language='JavaScript'> alert('Se envio un correo electronico donde se le asigno una nueva contrasena');</script>";
     $_POST = array();
	}else {$negado=1;}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>cambio de clave</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="100%">
  <tr>
    <td align="center"><h3>Restablecer Clave</h3></td>
  </tr>
  <tr>
    <td class="Tcabeza">&nbsp;</td>
  </tr>
  <tr>
    <td><form name="form1" method="post" action="">
      <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
        <tr>
          <td colspan="2"><h2>Datos de usuario</h2>
            <?php if (array_key_exists('enviar', $_POST) && $negado == 1){echo "<p class='obligatorio'>El nombre de usuario ingresado no existe </p>";} ?></td>
          </tr>
        <tr>
          <td width="50%"><label for="usuario">Nombre de Usuario:</label>
            <input name="usuario" type="text" class="textInput" id="usuario"></td>
          <td width="50%"><p>&nbsp;</p></td>
        </tr>
        <tr>
          <td width="50%">&nbsp;</td>
          <td width="50%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Recuperar"></td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td class="Tcabeza">&nbsp;</td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($obtenerUsuario);
?>
