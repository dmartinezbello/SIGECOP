<?php
include '../Connections/conex.php';
 
$q=$_POST['q'];
 
$res=mysql_query("select * from parroquia where NuCodMun=".$q."",$conex);

?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
</head>
<body>
<label>Parroquia:</label>
<select name="NuCodPar" id="NuCodPar" class="textInput" onChange="cargaComunidad(this.value)">
<option value="0">Seleccione una opci&oacute;n</option> 
 
<?php while($fila=mysql_fetch_array($res)){ ?>
<option value="<?php echo $fila['NuCodPar']; ?>"><?php echo $fila['TxDesPar']; ?></option>
<?php } ?>
 
</select>
</body>
</html>
