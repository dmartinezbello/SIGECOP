<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  <title>Untitled Document</title>
  <style type="text/css">
@font-face
{
   font-family: PTSansNarrow;
   src: url(../Fuentes/PTN57F.ttf);
}

body
{
   margin: 0px;
   background-color: #f0f0f0;
   font-family: PTSansNarrow;
   font-size: 14px;
   font-stretch: normal;
   border-top: 2px solid #eaeaea;
}

p
{
   margin: 0px;
}
</style>
</head>

<body>
  <div style="background:#f0f0f0; height:15px; width:100%;"> </div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"><p>Universidad Polit&eacute;cnica Territorial  &ldquo;Ludovico Silva&rdquo; Sede Punta de Mata</p>
        <p>&copy;2013 </p></td>
    </tr>
  </table>
</body>
</html>
