<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  <title>.:SIGECOP:.</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
    <table width="95%" border="0" cellpadding="0" cellspacing="20">
  <tr>
    <td width="70%" valign="top"><h1>Eje proyecto</h1></td>
    <td width="30%" rowspan="2" valign="top">
      <h3>Ultimas noticias</h3>
      <p><a href="http://www.aporrea.org/educacion/a147301.html"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> El Distrito Motor ?Nuevo modelo civilizatorio?</a></p>
      <p><a href="http://pueblopopularvenezuela.blogspot.com/2010/11/programas-nacionales-de-formacion-iutc.html"><span class="icon-vineta">&nbsp;&nbsp;&nbsp;&nbsp;</span> Un espacio para el debate de las ideas revolucionarias</a></p>
      <br>
      <h3>Links de interes</h3>
      <p> <a href="www.google.com"><img src="../img/social_google_box_blue.png" width="16" height="16" alt="google">Google</a></p>
      <p><a href="www.facaeboo.com"><img src="../img/facebook.png" width="14" height="14" alt="facebook"> Facebook</a></p>
      <p><a href="www.twiter.com"><img src="../img/twitter-icon.png" width="15" height="15" alt="twiter"> Twiter</a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center"><img src="../img/LogoSigecop2.png" width="235" height="213">
      <p>&nbsp;</p>
      <p>El Eje Curricular Proyecto  constituye el  eje central  de  formaci�n de los PNF ya que promueve la integraci�n multidimensional de los saberes y conocimientos a trav�s de una formaci�n te�rico-pr�ctica. Su objetivo estar� orientado a la   transformaci�n de la realidad mediante la participaci�n activa de los diferentes actores del hecho educativo y desarrollado con base a un quehacer metodol�gico que facilite el desarrollo de un bien o servicio. </p>
      <p>&nbsp;</p>
      <p>En este sentido,  el desarrollo de las actividades del proyecto   enfatizar�  el aprendizaje como proceso, el cual se construye con otros en un contexto integrador para potenciar las habilidades, destrezas y saberes (hacer, convivir, ser y el conocer) de los participantes hacia la b�squeda del mejoramiento de la calidad de vida de las comunidades, las regiones  y el pa�s en  articulaci�n  con los Planes estrat�gicos de la Naci�n.  Del mismo modo los Proyectos estar�n insertos en  las l�neas de investigaci�n de la Instituci�n  y enfocados a actividades estrechamente vinculadas con el perfil profesional de cada PNF para garantizar la aplicaci�n social del conocimiento. </p>
      <p>&nbsp;</p>
    <p>En funci�n de lo antes planteado, a continuaci�n se presentan las l�neas de investigaci�n  que se derivan de los programas nacionales de formaci�n, y que ser�n los puntos de partida para el desarrollo de los proyectos, puesto que los mismos deben estar insertos en alguna de estas. </p></td>
    </tr>
</table>
</body>
</html>