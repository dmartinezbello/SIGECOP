<?php require_once('../Connections/conex.php'); ?>
<?php
$docente=$_GET['cedula'];
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_docente = "-1";
if (isset($_GET['cedula'])) {
  $colname_docente = $_GET['cedula'];
}
mysql_select_db($database_conex, $conex);
$query_docente = sprintf("SELECT NuCedDoc, TxApeDoc, TxNomDoc, TxMovilDoc, TxFIjoDoc, TxDirDoc, TxEmailDoc FROM docente WHERE NuCedDoc = %s", GetSQLValueString($colname_docente, "text"));
$docente = mysql_query($query_docente, $conex) or die(mysql_error());
$row_docente = mysql_fetch_assoc($docente);
$totalRows_docente = mysql_num_rows($docente);

$colname_lineaInv = "-1";
if (isset($_POST['especialidad'])) {
  $colname_lineaInv = $_POST['especialidad'];
}
mysql_select_db($database_conex, $conex);
$query_lineaInv = sprintf("SELECT linea.TxNomLin, area.AuCodAre, area.NuCodLin, area.TxTraAre, area.TxDesAre FROM area, linea WHERE area.AuCodEsp = %s AND linea.AuCodLin=area.NuCodLin ORDER BY area.TxTraAre, linea.TxNomLin, TxDesAre ASC", GetSQLValueString($colname_lineaInv, "int"));
$lineaInv = mysql_query($query_lineaInv, $conex) or die(mysql_error());
$row_lineaInv = mysql_fetch_assoc($lineaInv);
$totalRows_lineaInv = mysql_num_rows($lineaInv);

mysql_select_db($database_conex, $conex);
$query_especialidad = "SELECT * FROM especialidad ORDER BY TxNomEsp ASC";
$especialidad = mysql_query($query_especialidad, $conex) or die(mysql_error());
$row_especialidad = mysql_fetch_assoc($especialidad);
$totalRows_especialidad = mysql_num_rows($especialidad);

$colname_lineaInvDoc = "-1";
if (isset($_GET['cedula'])) {
  $colname_lineaInvDoc = $_GET['cedula'];
}
mysql_select_db($database_conex, $conex);
$query_lineaInvDoc = sprintf("SELECT docentelinea.AuCodDocLin, area.TxTraAre, area.TxDesAre, linea.TxNomLin, especialidad.TxNomEsp FROM docentelinea, area, linea, especialidad WHERE NuCedDoc = %s AND area.AuCodAre = docentelinea.AuCodAre AND linea.AuCodLin = area.NuCodLin AND especialidad.AuCodEsp = area.AuCodEsp ORDER BY  especialidad.TxNomEsp, area.TxTraAre, linea.TxNomLin, TxDesAre ASC ", GetSQLValueString($colname_lineaInvDoc, "text"));
$lineaInvDoc = mysql_query($query_lineaInvDoc, $conex) or die(mysql_error());
$row_lineaInvDoc = mysql_fetch_assoc($lineaInvDoc);
$totalRows_lineaInvDoc = mysql_num_rows($lineaInvDoc);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>asignarle lineas de insvestigacion a docentes</title>
<link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Asociar L&iacute;neas de Investigaci&oacute;n a  Docentes</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td align="left"><table align="center">
          <tr>
            <td colspan="2"><h2>Datos de docente:</h2></td>
          </tr>
          <tr>
            <td colspan="2" align="left"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
              <tr>
                <th colspan="2" align="left" valign="baseline" class="lineaInfPunta">Datos personales</th>
                <th colspan="2" align="left" valign="bottom" class="lineaInfPunta">Datos de ubicaci&oacute;n</th>
                </tr>
              <tr>
                <td width="8%" valign="top"><p><strong>Nombre:</strong></p>
                  <p><strong>Cedula:</strong></p>
                  </td>
                <td width="46%" valign="top"><p><?php echo $row_docente['TxNomDoc']; ?>, <?php echo $row_docente['TxApeDoc']; ?></p>
                  <p><?php echo $row_docente['NuCedDoc']; ?></p></td>
                <td width="14%" valign="top"><p><strong>Tel&eacute;fono movil:</strong></p>
                  <p><strong>Telefono Fijo:</strong></p>
                  <p><strong>Correo electr&oacute;nico:</strong></p>
                  <p><strong>Direcci&oacute;n:</strong></p></td>
                <td width="32%" valign="top"><p><?php echo $row_docente['TxMovilDoc']; ?></p>
                  <p><?php echo $row_docente['TxFIjoDoc']; ?></p>
                  <p><?php echo $row_docente['TxEmailDoc']; ?></p>
                  <p><?php echo $row_docente['TxDirDoc']; ?></p></td>
                </tr>
              <tr>
                <td colspan="4" align="left" valign="top" class="lineaInfPunta"><h2>Lineas de investigacion adcritas</h2></td>
              </tr>
              <tr>
                <td colspan="4" valign="top" class="lineaInfPunta"><?php if ($totalRows_lineaInvDoc == 0) { // Show if recordset empty ?>
                    A&uacute;n no se han establecido l&iacute;neas de insvestigaci&oacute;n
  <?php } // Show if recordset empty ?>
<?php if ($totalRows_lineaInvDoc > 0) { // Show if recordset not empty ?>
  <table width="100%" border="0" align="left" cellpadding="5" cellspacing="0">
    <tr>
      <th width="20%" align="left">Especialidad</th>
      <th width="30%" align="left">L&iacute;nea de investigaci&oacute;n</th>
      <th width="35%" align="left">&Aacute;reas de desarrollo</th>
      <th width="10%">Trayecto</th>
      <th width="5%">Eliminar</th>
    </tr>
    <?php do { ?>
      <tr>
        <td width="20%"><?php echo $row_lineaInvDoc['TxNomEsp']; ?></td>
        <td width="30%"><?php echo $row_lineaInvDoc['TxNomLin']; ?></td>
        <td width="35%"><?php echo $row_lineaInvDoc['TxDesAre']; ?></td>
        <td width="10%" align="center"><?php echo $row_lineaInvDoc['TxTraAre']; ?></td>
        <td width="5%" align="center"><a href="del-lineaInv.php?cedula=<?php echo $row_docente['NuCedDoc']; ?>&lineaInv=<?php echo $row_lineaInvDoc['AuCodDocLin']; ?>"><span class="icon-del">&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
      </tr>
      <?php } while ($row_lineaInvDoc = mysql_fetch_assoc($lineaInvDoc)); ?>
  </table>
  <?php } // Show if recordset not empty ?></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td width="1017" align="right">&nbsp;</td>
            <td width="37" align="right">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="2" align="right"><form name="form1" method="post" action="">
              <select name="especialidad" id="especialidad">
                <option value="">Seleccione una especialidad</option>
                <?php
do {  
?>
                <option value="<?php echo $row_especialidad['AuCodEsp']?>"><?php echo $row_especialidad['TxNomEsp']?></option>
                <?php
} while ($row_especialidad = mysql_fetch_assoc($especialidad));
  $rows = mysql_num_rows($especialidad);
  if($rows > 0) {
      mysql_data_seek($especialidad, 0);
	  $row_especialidad = mysql_fetch_assoc($especialidad);
  }
?>
            </select>
              <input name="button" type="submit" class="button" id="button" value="Filtrar">
            </form></td>
          </tr>
          <?php if ($totalRows_lineaInv > 0) { // Show if recordset not empty ?>
  <tr>
    <td colspan="2" align="left"><p><strong>Programa Nacional de Formaci&oacute;n en <?php echo $row_lineaInv['TxNomEsp']; ?></strong></p>
      <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
        <tr>
          <th align="left" class="Tcabeza">Linea de Investigaci&oacute;n</th>
          <th align="left" class="Tcabeza">&Aacute;rea de desarrollo</th>
          <th class="Tcabeza">Trayecto</th>
          <td class="Tcabeza">&nbsp;</td>
        </tr>
        <?php do { ?>
          <tr>
            <td class="lineaInfPunta"><?php echo $row_lineaInv['TxNomLin']; ?></td>
            <td class="lineaInfPunta"><?php echo $row_lineaInv['TxDesAre']; ?></td>
            <td align="center" class="lineaInfPunta"><?php echo $row_lineaInv['TxTraAre']; ?></td>
            <td align="center" class="lineaInfPunta"><a href="add-lineaInv.php?cedula=<?php echo $row_docente['NuCedDoc']; ?>&lineaInv=<?php echo $row_lineaInv['AuCodAre']; ?>"><span class="icon-add">&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
          </tr>
          <?php } while ($row_lineaInv = mysql_fetch_assoc($lineaInv)); ?>
      </table>
      <p>&nbsp;</p></td>
  </tr>
  <?php } // Show if recordset not empty ?>
      </table></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($docente);

mysql_free_result($lineaInv);

mysql_free_result($especialidad);

mysql_free_result($lineaInvDoc);
?>
