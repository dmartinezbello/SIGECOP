<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
//Juego de registro para identificar el proyecto
$colname_identificarProyecto = "-1";
if (isset($_GET['proyecto'])) {
  $colname_identificarProyecto = $_GET['proyecto'];
}
mysql_select_db($database_conex, $conex);
$query_identificarProyecto = sprintf("SELECT proyecto.TxTitPro, proyecto.DtRegPro, proyecto.TxConPro, proyecto.TxEstPro, institucion.TxNomIns, institucion.TxComIns, parroquia.TxDesPar, municipio.TxDesMun, estado.TxDesEst, proyecto.TxCodPro, area.TxDesAre, linea.TxNomLin, especialidad.TxNomEsp, area.AuCodAre FROM proyecto, institucion, parroquia, municipio, estado, area, linea, especialidad WHERE TxCodPro = %s AND institucion.AuCodIns = proyecto.AuNomIns AND parroquia.NuCodPar =  institucion.NuCodPar AND municipio.NuCodMun = parroquia.NuCodMun AND estado.NuCodEst = municipio.NuCodEst AND area.AuCodAre=proyecto.AuCodAre AND linea.AuCodLin=area.NuCodLin AND area.AuCodEsp = especialidad.AuCodEsp", GetSQLValueString($colname_identificarProyecto, "text"));
$identificarProyecto = mysql_query($query_identificarProyecto, $conex) or die(mysql_error());
$row_identificarProyecto = mysql_fetch_assoc($identificarProyecto);
$totalRows_identificarProyecto = mysql_num_rows($identificarProyecto);

// REGISTRAR TUTORES ---------------------------------------------------------------------------------------------------------------------------------
// verificar tutor duplicados
mysql_select_db($database_conex, $conex);
$query_duplicadoDoc = "SELECT * FROM  jurado WHERE TxCodPro = '".$_GET['proyecto']."' AND  TxCedDoc = '".$_POST['TxCedDoc']."'";
$duplicadoDoc = mysql_query($query_duplicadoDoc, $conex) or die(mysql_error());
$row_duplicadoDoc = mysql_fetch_assoc($duplicadoDoc);
$totalRows_duplicadoDoc = mysql_num_rows($duplicadoDoc);

// Verificar si el numero de cedula ingresado corresponde a un docente
$colname_existeTotor = "-1";
if (isset($_POST['TxCedDoc'])) {
  $colname_existeTotor = $_POST['TxCedDoc'];
}
mysql_select_db($database_conex, $conex);
$query_existeTotor = sprintf("SELECT NuCedDoc FROM docente WHERE NuCedDoc = %s", GetSQLValueString($colname_existeTotor, "text"));
$existeTotor = mysql_query($query_existeTotor, $conex) or die(mysql_error());
$row_existeTotor = mysql_fetch_assoc($existeTotor);
$totalRows_existeTotor = mysql_num_rows($existeTotor);

if (array_key_exists ('docente', $_POST)){
	if($totalRows_existeTotor > 0){
	if ($totalRows_duplicadoDoc==0){
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form3")) {
  $insertSQL = sprintf("INSERT INTO jurado (AuCodJur, TxCodPro, TxCedDoc, TxTipDoc) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodJur'], "int"),
                       GetSQLValueString($_GET['proyecto'], "text"),
                       GetSQLValueString($_POST['TxCedDoc'], "text"),
                       GetSQLValueString("t", "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  echo "<script language='JavaScript'> alert('Se ha relacionado un docente en calidad de tutor a este proyecto');</script>";
  $_POST = array();
}
	}else{echo "<script language='JavaScript'> alert('No se realizo el proceso de registro porque el docente que intenta agregar ya esta asociado');</script>";}
}else{echo "<script language='JavaScript'> alert('Se detecto un intento de registro que no se llevo a cabo porque el dato ingresado no corresponde a ningun docente registrado');</script>";}
}else{$error=1;}

// REGISTRAR JURADO ---------------------------------------------------------------------------------------------------------------------------
// Validar que se les hayan colocado datos a los campos requeridos
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxCedDoc']) && !empty($_POST['TxTipDoc'])) {
if ($totalRows_duplicadoDoc==0){
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO jurado (AuCodJur, TxCodPro, TxCedDoc, TxTipDoc) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodJur'], "int"),
                       GetSQLValueString($_GET['proyecto'], "text"),
                       GetSQLValueString($_POST['TxCedDoc'], "text"),
                       GetSQLValueString($_POST['TxTipDoc'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  echo "<script language='JavaScript'> alert('Se ha relacionado un docente en calidad de jurado a este proyecto');</script>";
  $_POST = array();
}
}else{echo "<script language='JavaScript'> alert('Se detecto un intento de registro que no se llevo a cabo porque crearia una duplicidad en las relaciones de docentes');</script>";}
}else{$error=1;}

//Verificar que esxita el numero de cedula del estudiante para ingresarlo al grupo
$colname_buscaEstudiante = "-1";
if (isset($_POST['TxCedest'])) {
  $colname_buscaEstudiante = $_POST['TxCedest'];
}
mysql_select_db($database_conex, $conex);
$query_buscaEstudiante = sprintf("SELECT TxMailEst FROM estudiante WHERE TxCedEst = %s", GetSQLValueString($colname_buscaEstudiante, "text"));
$buscaEstudiante = mysql_query($query_buscaEstudiante, $conex) or die(mysql_error());
$row_buscaEstudiante = mysql_fetch_assoc($buscaEstudiante);
$totalRows_buscaEstudiante = mysql_num_rows($buscaEstudiante);
$estudiante_duplicado=0;
// Verificar si un estudiante ya fue registrado para evitar duplicados

$colname_duplicadoEstGru = "-1";
if (isset($_POST['TxCedest'])) {
  $colname_duplicadoEstGru = $_POST['TxCedest'];
}
mysql_select_db($database_conex, $conex);
$query_duplicadoEstGru = sprintf("SELECT TxCedest FROM grupos WHERE TxCedest = %s AND TxCodPro='".$_GET['proyecto']."'", GetSQLValueString($colname_duplicadoEstGru, "text"));
$duplicadoEstGru = mysql_query($query_duplicadoEstGru, $conex) or die(mysql_error());
$row_duplicadoEstGru = mysql_fetch_assoc($duplicadoEstGru);
$totalRows_duplicadoEstGru = mysql_num_rows($duplicadoEstGru);
//REGISTRAR ESTUDIANTES -----------------------------------------------------------------------------------------------------------------------------
if ($totalRows_duplicadoEstGru == 0){
if (array_key_exists ('enviar2', $_POST)){
if ($totalRows_buscaEstudiante > 0){
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO grupos (NuCodGru, TxCodPro, TxCedest) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['NuCodGru'], "int"),
                       GetSQLValueString($_GET['proyecto'], "text"),
                       GetSQLValueString($_POST['TxCedest'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  // Enviar email de confimacion
  require('../phpmailer/correos.php');
  confirmarRelacionProyecto($row_buscaEstudiante['TxMailEst'], $_GET['proyecto'], $row_identificarProyecto['TxTitPro']);

  
  $_POST = array();
}
}else {echo "<script language='JavaScript'> alert('El proceso de registro fallo, el numero de cedula ingresado no esta asociado a ningun estudiante');</script>";}
}
}else {echo "<script language='JavaScript'> alert('Se detecto un intento de registro que no se llevo a cabo porque crearia una duplicidad en las relaciones de estudiantes ');</script>";}

$area_docentes = "-1";
if (isset($row_identificarProyecto['AuCodAre'])) {
  $area_docentes = $row_identificarProyecto['AuCodAre'];
}
mysql_select_db($database_conex, $conex);
$query_docentes = sprintf("SELECT docentelinea.NuCedDoc, docente.TxApeDoc, docente.TxNomDoc FROM docentelinea, docente WHERE AuCodAre=%s AND docente.NuCedDoc=docentelinea.NuCedDoc ORDER BY docente.TxApeDoc ASC", GetSQLValueString($area_docentes, "int"));
$docentes = mysql_query($query_docentes, $conex) or die(mysql_error());
$row_docentes = mysql_fetch_assoc($docentes);
$totalRows_docentes = mysql_num_rows($docentes);

mysql_select_db($database_conex, $conex);
$query_detalleGrupo = "SELECT  grupos.NuCodGru, estudiante.TxCedEst, estudiante.TxApeEst, estudiante.TxNomEst, estudiante.TxMovilEst, estudiante.TxFijoEst, estudiante.TxMailEst FROM  grupos, estudiante WHERE  TxCodPro = '".$_GET['proyecto']."' AND estudiante.TxCedEst = grupos.TxCedest";
$detalleGrupo = mysql_query($query_detalleGrupo, $conex) or die(mysql_error());
$row_detalleGrupo = mysql_fetch_assoc($detalleGrupo);
$totalRows_detalleGrupo = mysql_num_rows($detalleGrupo);

//docentes relacionados
$colname_DocRelacionados = "-1";
if (isset($_GET['proyecto'])) {
  $colname_DocRelacionados = $_GET['proyecto'];
}
mysql_select_db($database_conex, $conex);
$query_DocRelacionados = sprintf("SELECT docente.NuCedDoc, docente.TxApeDoc, docente.TxNomDoc, docente.TxMovilDoc, docente.TxFIjoDoc, docente.TxEmailDoc, jurado.TxTipDoc, jurado.AuCodJur FROM jurado, docente WHERE TxCodPro = %s AND docente.NuCedDoc=jurado.TxCedDoc ORDER BY jurado.TxTipDoc DESC, docente.TxApeDoc ASC", GetSQLValueString($colname_DocRelacionados, "text"));
$DocRelacionados = mysql_query($query_DocRelacionados, $conex) or die(mysql_error());
$row_DocRelacionados = mysql_fetch_assoc($DocRelacionados);
$totalRows_DocRelacionados = mysql_num_rows($DocRelacionados);

?>

<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>asociar estudiantes y tutores</title>
  <script type="text/javascript" src="../js/ajax.js"></script>
  <script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
  <link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Asociar Estudiantes y Tutores</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td><fieldset>
          <legend>
          <h2>Datos del proyecto</h2>
          </legend>
          <table width="95%" border="0" align="center" cellpadding="5" cellspacing="0">
            <tr>
              <td width="50%" align="center"
				<?php if($row_identificarProyecto['TxEstPro']=="p"){echo "bgcolor='#666666'";}
				      if($row_identificarProyecto['TxEstPro']=="e"){echo "bgcolor='#0066ff'";}
						if($row_identificarProyecto['TxEstPro']=="c"){echo "bgcolor='#ff9900'";}
						if($row_identificarProyecto['TxEstPro']=="a"){echo "bgcolor='#00cc33'";}
						if($row_identificarProyecto['TxEstPro']=="r"){echo "bgcolor='#ff0000'";}
				?>><?php 
				if($row_identificarProyecto['TxEstPro']=="p"){echo "<span class='estatus'>En proceso</span>";}
				if($row_identificarProyecto['TxEstPro']=="e"){echo "<span class='estatus'>En revisi&oacute;n</span>";}
				if($row_identificarProyecto['TxEstPro']=="c"){echo "<span class='estatus'>Condicionado</span>";}
				if($row_identificarProyecto['TxEstPro']=="a"){echo "<span class='estatus'>Aprobado</span>";}
				if($row_identificarProyecto['TxEstPro']=="r"){echo "<span class='estatus'>Reprobado</span>";}
				?></td>
              <td width="50%" align="center" 
            <?php if ($row_identificarProyecto['TxConPro']==0){echo 'bgcolor="#FF0000"';}
				      if ($row_identificarProyecto['TxConPro']==1){echo 'bgcolor="#00cc33"';}
				?>
            ><?php 
				if ($row_identificarProyecto['TxConPro']==0){echo '<span class="estatus">Ejemplar no consignado</span>';}
				if ($row_identificarProyecto['TxConPro']==1){echo '<span class="estatus">Ejemplar consignado</span>';}
				?></td>
            </tr>
            <?php do { ?>
              <tr>
                <td colspan="2"><p style="font-size:22px;"><strong>C&Oacute;DIGO:</strong> <span class="obligatorio" style="font-size:22px;"><?php echo $row_identificarProyecto['TxCodPro']; ?></span></p>
                  <p><strong>Registrado el: </strong><?php echo $row_identificarProyecto['DtRegPro']; ?></p>
                  <p>&nbsp;</p>
                  <p><strong>T&iacute;tulo: </strong><?php echo $row_identificarProyecto['TxTitPro']; ?></p>
                  <p><strong>L&iacute;nea de investigaci&oacute;n y desarrollo:</strong> &Aacute;rea de desarrollo <strong><?php echo $row_identificarProyecto['TxDesAre']; ?></strong> dependiente de la l&iacute;nea de investigaci&oacute;n <strong><?php echo $row_identificarProyecto['TxNomLin']; ?></strong> de la especialidad <strong><?php echo $row_identificarProyecto['TxNomEsp']; ?></strong></p>
                  <p><strong>Contexto geogr&aacute;fico:</strong> <?php echo $row_identificarProyecto['TxNomIns']; ?> ubicado en la comunidad <?php echo $row_identificarProyecto['TxComIns']; ?> de la parroquia <?php echo $row_identificarProyecto['TxDesPar']; ?> municipio <?php echo $row_identificarProyecto['TxDesMun']; ?> del estado <?php echo $row_identificarProyecto['TxDesEst']; ?></p></td>
              </tr>
              <?php } while ($row_identificarProyecto = mysql_fetch_assoc($identificarProyecto)); ?>
          </table>
        </fieldset>
        <fieldset>
          <legend>
          <h2>Relacionar docentes</h2>
          </legend>
          <form action="<?php echo $editFormAction; ?>" method="post" name="form3">
            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
              <tr valign="baseline">
                <td colspan="2" align="left" nowrap><h3>Tutor</h3></td>
              </tr>
              <tr valign="baseline">
                <td width="42%" align="right" nowrap><label>C&eacute;dula del docente:</label>
                  <span id="sprytextfield2">
                  <input name="TxCedDoc" type="text" class="textInput" id="TxCedDoc" onKeyUp="carga_tutor(this.value)" size="32">
                  </span></td>
                <td width="58%" valign="bottom"><input name="docente" type="submit" class="button" id="docente" value="Agregar"></td>
              </tr>
              <tr valign="baseline">
                <td colspan="2" align="left" nowrap><div id="tutor"></div></td>
              </tr>
            </table>
            <input type="hidden" name="MM_insert" value="form3">
            <input type="hidden" name="TxTipDoc2" value="t" size="32">
          </form>
          <form action="<?php echo $editFormAction; ?>" method="post" name="form1">
            <label>
            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
              <?php if (array_key_exists ('enviar', $_POST) && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
              <tr valign="baseline">
                <td colspan="3" align="left" nowrap><h3>Jurado</h3></td>
              </tr>
              <tr valign="baseline">
                <td width="20%" align="right" nowrap><label>C&eacute;dula del docente:
                    <?php if (array_key_exists ('enviar', $_POST) && $_POST['TxCedDoc'] == "0") { echo $icono;}?>
                  </label>
                  <select name="TxCedDoc" class="textInput" id="TxCedDoc" style="height:28px;">
                    <option value="0">Seleccione una opcion</option>
                    <?php
do {  
?>
                    <option value="<?php echo $row_docentes['NuCedDoc']?>"><?php echo $row_docentes['NuCedDoc'].' - '.$row_docentes['TxApeDoc'].', '.$row_docentes['TxNomDoc']?></option>
                    <?php
} while ($row_docentes = mysql_fetch_assoc($docentes));
  $rows = mysql_num_rows($docentes);
  if($rows > 0) {
      mysql_data_seek($docentes, 0);
	  $row_docentes = mysql_fetch_assoc($docentes);
  }
?>
                  </select></td>
                <td width="20%"><label>Clasificaci&oacute;n:
                    <?php if (array_key_exists ('enviar', $_POST) && $_POST['TxTipDoc'] == "0") { echo $icono;}?>
                  </label>
                  <select name="TxTipDoc" class="textInput" style="height:28px;">
                    <option value="0" <?php if (!(strcmp(0, ""))) {echo "SELECTED";} ?>>Seleccione una opcion</option>
                    <option value="p" <?php if (!(strcmp("p", ""))) {echo "SELECTED";} ?>>Jurado principal</option>
                    <option value="s" <?php if (!(strcmp("s", ""))) {echo "SELECTED";} ?>>Jurado suplente</option>
                  </select></td>
                <td width="60%" valign="bottom"><input name="enviar" type="submit" class="button" id="enviar" value="Agregar"></td>
              </tr>
              <tr valign="baseline">
                <td colspan="3" align="right" nowrap>&nbsp;
                  <?php if ($totalRows_DocRelacionados > 0) { // Show if recordset not empty ?>
                    <table width="100%" border="0" align="left" cellpadding="10" cellspacing="1">
                      <tr class="Tcabeza">
                        <th width="35%" align="left">Docente</th>
                        <th width="25%" align="left">Tel&eacute;fonos</th>
                        <th width="25%" align="left">Correo electronico</th>
                        <th width="10%" align="center">Clasificaci&oacute;n</th>
                        <th width="5%">eliminar</th>
                      </tr>
                      <?php do { ?>
                        <tr>
                          <td width="35%" class="lineaInfPunta"><?php echo $row_DocRelacionados['NuCedDoc']; ?><br><?php echo $row_DocRelacionados['TxApeDoc']; ?>, <?php echo $row_DocRelacionados['TxNomDoc']; ?></td>
                          <td width="25%" align="left" class="lineaInfPunta"><strong style="padding:0px 10px 0px 0px">Movil:</strong> <?php echo $row_DocRelacionados['TxMovilDoc']; ?><br><strong style="padding:0px 23px 0px 0px">Fijo:</strong><?php echo $row_DocRelacionados['TxFIjoDoc']; ?></td>
                          <td width="25%" class="lineaInfPunta"><?php echo $row_DocRelacionados['TxEmailDoc']; ?></td>
                          <td width="10%" align="center" class="lineaInfPunta"><?php if ($row_DocRelacionados['TxTipDoc']=="t"){echo 'Tutor';}
						  															 if ($row_DocRelacionados['TxTipDoc']=="p"){echo 'Jurado principal';}
																					 if ($row_DocRelacionados['TxTipDoc']=="s"){echo 'Jurado suplente';}?></td>
                          <td width="5%" align="center" class="lineaInfPunta"><a href="del-tut-jur.php?jurado=<?php echo $row_DocRelacionados['AuCodJur']; ?>&proyecto=<?php echo $_GET['proyecto']; ?>"><span class="icon-del">&nbsp;</span></a></td>
                        </tr>
                        <?php } while ($row_DocRelacionados = mysql_fetch_assoc($DocRelacionados)); ?>
                    </table>
                <?php } // Show if recordset not empty ?></td>
              </tr>
            </table>
            </label>
            <input type="hidden" name="MM_insert" value="form1">
          </form>
        </fieldset>
        <fieldset>
          <legend>
          <h2>Relacionar estudiantes</h2>
          </legend>
          <form method="post" name="form2" action="<?php echo $editFormAction; ?>">
            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
              <tr valign="baseline">
                <td width="42%" align="right" nowrap><label>C&eacute;dula estudiante:</label>
                  <span id="sprytextfield1">
                  <input name="TxCedest" type="text" class="textInput" value="" size="32" style="height:26px;" onKeyUp="carga_estudiante(this.value)">
                  <span class="textfieldInvalidFormatMsg"></span></span></td>
                <td width="58%" valign="bottom"><input name="enviar2" type="submit" class="button" id="enviar2" value="Agregar"></td>
              </tr>
              <tr valign="baseline">
                <td colspan="2" align="left" nowrap><div id="estudiante"></div></td>
              </tr>
              <tr valign="baseline">
                <td colspan="2" align="left" nowrap>
                  <?php if ($totalRows_detalleGrupo > 0) { // Show if recordset not empty ?>
                    <table width="100%" border="0" cellpadding="10" cellspacing="1">
                      <tr class="Tcabeza">
                        <th width="45%" align="left">Estudiante</th>
                        <th width="25%" align="left">T&eacute;lefonos</th>
                        <th width="25%" align="left">Correo electronico</th>
                        <th width="5%">Eliminar</th>
                      </tr>
                      <?php do { ?>
                        <tr>
                          <td width="45%" class="lineaInfPunta"><?php echo $row_detalleGrupo['TxCedEst']; ?> <br> <?php echo $row_detalleGrupo['TxApeEst']; ?>, <?php echo $row_detalleGrupo['TxNomEst']; ?></td>
                          <td width="25%" align="left" class="lineaInfPunta"><strong style="padding:0px 10px 0px 0px">Movil:</strong><?php echo $row_detalleGrupo['TxMovilEst']; ?><br>
                          <strong style="padding:0px 21px 0px 0px">Fijo:</strong><?php echo $row_detalleGrupo['TxFijoEst']; ?></td>
                          <td width="25%" class="lineaInfPunta"><?php echo $row_detalleGrupo['TxMailEst']; ?></td>
                          <td width="5%" class="lineaInfPunta" align="center"><a href="del-est-grup.php?grupo=<?php echo $row_detalleGrupo['NuCodGru']; ?>&proyecto=<?php echo $_GET['proyecto']; ?>"><span class="icon-del">&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
                        </tr>
                        <?php } while ($row_detalleGrupo = mysql_fetch_assoc($detalleGrupo)); ?>
                    </table>
                <?php } // Show if recordset not empty ?></td>
              </tr>
            </table>
            <input type="hidden" name="MM_insert" value="form2">
          </form>
        </fieldset></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {pattern:"A-00.000.000", useCharacterMasking:true, isRequired:false, hint:"V-00.000.000"});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "social_security_number", {isRequired:false, useCharacterMasking:true, format:"ssn_custom", pattern:"A-00.000.000", hint:"V-00.000.000"});
  </script>
</body>
</html>
<?php
mysql_free_result($identificarProyecto);

mysql_free_result($docentes);

mysql_free_result($DocRelacionados);

mysql_free_result($existeTotor);

mysql_free_result($detalleGrupo);

mysql_free_result($duplicadoEstGru);

mysql_free_result($buscaEstudiante);

mysql_free_result($duplicadoDoc);

?>
