<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php include('../recursos/funciones.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

// Consultar si el numero de cedula ingresado por el usuario ya esta registrado
$colname_estudiantes = "-1";
if (isset($_POST['TxCedEst'])) {
  $colname_estudiantes = $_POST['TxCedEst'];
}
mysql_select_db($database_conex, $conex);
$query_estudiantes = sprintf("SELECT TxCedEst FROM estudiante WHERE TxCedEst = %s", GetSQLValueString($colname_estudiantes, "text"));
$estudiantes = mysql_query($query_estudiantes, $conex) or die(mysql_error());
$row_estudiantes = mysql_fetch_assoc($estudiantes);
$totalRows_estudiantes = mysql_num_rows($estudiantes);
// Consultar si el correo electronico ingresado por el usuario ya esta registrado en la tabla usuarios
$colname_usuarios = "-1";
if (isset($_POST['TxMailEst'])) {
  $colname_usuarios = $_POST['TxMailEst'];
}
mysql_select_db($database_conex, $conex);
$query_usuarios = sprintf("SELECT * FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_usuarios, "text"));
$usuarios = mysql_query($query_usuarios, $conex) or die(mysql_error());
$row_usuarios = mysql_fetch_assoc($usuarios);
$totalRows_usuarios = mysql_num_rows($usuarios);
//datos de usuario
$_POST['TxLogUsu']=$_POST['TxMailEst'];
$_POST['TxPasUsu']=$_POST['TxCedEst'];
$_POST['NuNivelUsu']=1;
// Validar que se les hayan colocado datos a los campos requeridos y que se haya indroducido un email en el campo email
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxCedEst']) && !empty($_POST['TxApeEst']) && !empty($_POST['TxNomEst']) && !empty($_POST['TxDirEst']) && !empty($_POST['TxMailEst']) && !empty($_POST['NuCodEsp']) && check_email_address($_POST['TxMailEst']) == 1) {
// Validar que no se vaya a incluir un dato duplicado
if ($totalRows_estudiantes == 0 && $totalRows_usuarios == 0){
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  // Volcar los datos de un nuevo usuario a la base de datos
  if ($totalRows_usuarios == 0){
  $insertSQL2 = sprintf("INSERT INTO usuarios (TxLogUsu, TxPasUsu, NuNivelUsu) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['TxLogUsu'], "text"),
                       GetSQLValueString($_POST['TxPasUsu'], "text"),
                       GetSQLValueString($_POST['NuNivelUsu'], "int"));
  mysql_select_db($database_conex, $conex);
  $Result2 = mysql_query($insertSQL2, $conex) or die(mysql_error());}
// Volcar datos del nuevo estudiante a la base de datos
  $insertSQL = sprintf("INSERT INTO estudiante (TxCedEst, TxApeEst, TxNomEst, TxMovilEst, TxFijoEst, TxDirEst, TxMailEst, DtRegEst, NuCodEsp, TxLogUsu) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString(ucwords($_POST['TxCedEst']), "text"),
                       GetSQLValueString(ucwords($_POST['TxApeEst']), "text"),
                       GetSQLValueString(ucwords($_POST['TxNomEst']), "text"),
                       GetSQLValueString($_POST['TxMovilEst'], "text"),
                       GetSQLValueString($_POST['TxFijoEst'], "text"),
                       GetSQLValueString(ucfirst($_POST['TxDirEst']), "text"),
                       GetSQLValueString($_POST['TxMailEst'], "text"),
                       GetSQLValueString($_POST['DtRegEst'], "date"),
                       GetSQLValueString($_POST['NuCodEsp'], "int"),
                       GetSQLValueString($_POST['TxLogUsu'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  //enviar correo de confirmacion de registro
  $nombre= ucwords($_POST['TxNomEst']).' '.ucwords($_POST['TxApeEst']);
  include('../phpmailer/correoConfirmarRegistro.php');
  confirmarRegistro($_POST['TxMailEst'], ucwords($_POST['TxCedEst']), $nombre);
  
  $_POST = array();
  echo "<script language='JavaScript'> alert('El proceso de registro se realizo con exito');</script>";
	}
}
}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}

// Consultar las especialidades registradas para volcarlas en el campo de seleccion especialidad
mysql_select_db($database_conex, $conex);
$query_especialidad = "SELECT * FROM especialidad ORDER BY TxNomEsp ASC";
$especialidad = mysql_query($query_especialidad, $conex) or die(mysql_error());
$row_especialidad = mysql_fetch_assoc($especialidad);
$totalRows_especialidad = mysql_num_rows($especialidad);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>Registro de estudiantes</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
  <link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
  <script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="100%">
      <tr>
        <td align="center"><h3>Registrar Estudiante</h3></td>
      </tr>
      <tr>
        <td class="Tcabeza">&nbsp;</td>
      </tr>
      <tr>
        <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
            <?php if ($_POST && $totalRows_usuarios > 0) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$dupUsuario.'</td></tr>';}?>
            <?php if ($_POST && $totalRows_estudiantes > 0) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$duplicado.'</td></tr>';}?>
            <?php if ($_POST && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
            <tr valign="baseline">
              <td colspan="2" nowrap><h2>Datos personales</h2></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" nowrap><span id="sprytextfield1">
                <label>C&eacute;dula:<span class="textfieldInvalidFormatMsg"> Formato no v�lido, debe seguir el patr&oacute;n <span style="font-family:Tahoma, Geneva, sans-serif; font-size:12px;">V-00.000.000</span> </span>
                  <?php if ($_POST && $_POST['TxCedEst'] == "") { echo $icono;}?>
                  <?php if ($_POST && $totalRows_estudiantes > 0) { echo $iconoAzul;}?>
                </label>
                <input name="TxCedEst" type="text" class="textInput capitalizar" id="TxCedEst" value="<?php if (isset($_POST['TxCedEst'])) {echo htmlentities($_POST['TxCedEst']);} ?>" size="32">
                </span></td>
              <td>&nbsp;</td>
            </tr>
            <tr valign="baseline">
              <td width="50%" nowrap><label>Apellido(s):
                  <?php if ($_POST && $_POST['TxApeEst'] == "") { echo $icono;}?>
                </label>
                <input name="TxApeEst" type="text" class="textInput capitalizar" value="<?php if (isset($_POST['TxApeEst'])) {echo htmlentities($_POST['TxApeEst']);} ?>" size="32"></td>
              <td><label>Nombre(s):
                  <?php if ($_POST && $_POST['TxNomEst'] == "") { echo $icono;}?>
                </label>
                <input name="TxNomEst" type="text" class="textInput capitalizar" value="<?php if (isset($_POST['TxNomEst'])) {echo htmlentities($_POST['TxNomEst']);} ?>" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" nowrap><span id="sprytextfield2">
                <label>Tel&eacute;fono movil: <span class="textfieldInvalidFormatMsg">&nbsp;Formato no v�lido, debe seguir el patr&oacute;n <span class="numerico">(0000) - 000 00 00</span></span></label>
                <input name="TxMovilEst" type="text" class="textInput" value="<?php if (isset($_POST['TxMovilEst'])) {echo htmlentities($_POST['TxMovilEst']);} ?>" size="32">
                </span></td>
              <td><span id="sprytextfield3">
                <label>Tel&eacute;fono fijo: <span class="textfieldInvalidFormatMsg">&nbsp;Formato no v�lido, debe seguir el patr&oacute;n <span class="numerico">(0000) - 000 00 00</span></span></label>
                <input name="TxFijoEst" type="text" class="textInput" value="<?php if (isset($_POST['TxFijoEst'])) {echo htmlentities($_POST['TxFijoEst']);} ?>" size="32">
                <span class="textfieldInvalidFormatMsg"></span></span></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" nowrap><label>Correo electr&oacute;nico:
                  <?php if ($_POST && $_POST['TxMailEst'] == "") { echo $icono;}?>
                  <?php if ($_POST && $totalRows_usuarios > 0) { echo $iconoVerde;}?>
                  <?php if ($_POST && $_POST['TxMailEst']!= "" && check_email_address($_POST['TxMailEst']) != 1) {echo '<span class="obligatorio">Direccion de correo electronico no valida</span>';}?>
                </label>
                <input name="TxMailEst" type="text" class="textInput" value="<?php if (isset($_POST['TxMailEst'])) {echo htmlentities($_POST['TxMailEst']);} ?>" size="32"></td>
              <td><label>Especialidad:
                  <?php if ($_POST && $_POST['NuCodEsp'] == "") { echo $icono;}?>
                </label>
                <select name="NuCodEsp" class="textInput">
                  <option value="" >Seleccione una opcion</option>
                  <?php
					do {  
				?>
                  <option value="<?php echo $row_especialidad['AuCodEsp']?>"><?php echo $row_especialidad['TxNomEsp']?></option>
                  <?php
					} while ($row_especialidad = mysql_fetch_assoc($especialidad));
					  $rows = mysql_num_rows($especialidad);
					  if($rows > 0) {
							mysql_data_seek($especialidad, 0);
						  $row_especialidad = mysql_fetch_assoc($especialidad);
					  }
				?>
                </select></td>
            </tr>
            <tr valign="baseline">
              <td colspan="2" nowrap><label>Direcci&oacute;n:
                  <?php if ($_POST && $_POST['TxDirEst'] == "") { echo $icono;}?>
                </label>
                <textarea name="TxDirEst" cols="50" rows="5" class="letracapital"><?php if (isset($_POST['TxDirEst'])) {echo htmlentities($_POST['TxDirEst']);} ?>
</textarea></td>
            </tr>
            <tr valign="baseline">
              <td colspan="2" nowrap><input type="hidden" name="TxLogUsu" value="" size="32">
                <input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
                <input name="Restablecer" type="reset" class="button der" value="Restablecer">
                <input type="submit" class="button der" value="Cancelar"></td>
            </tr>
          </table></td>
      </tr>
      <tr>
        <td class="Tcabeza">&nbsp;</td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1">
  </form>
  <script type="text/javascript">
				var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "custom", {pattern:"A-00.000.000", useCharacterMasking:true, isRequired:false, validateOn:["blur", "change"], hint:"V-00.000.000"});
				var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom", {isRequired:false, pattern:"(0000) - 000 00 00", useCharacterMasking:true, validateOn:["blur", "change"]});
				var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "custom", {pattern:"(0000) - 000 00 00", isRequired:false, useCharacterMasking:true, validateOn:["blur", "change"]});
        </script>
</body>
</html>
<?php
mysql_free_result($especialidad);

mysql_free_result($usuarios);

mysql_free_result($estudiantes);
?>
