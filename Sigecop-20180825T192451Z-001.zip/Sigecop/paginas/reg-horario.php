<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
$proMax=0;
$horaMax=0;
if(isset($_GET['aula'])){
$aula = $_GET['aula'];
}
if(isset($_GET['fecha'])){
$fecha = $_GET['fecha'];
}
if(array_key_exists('buscar', $_POST)){
$fecha = $_POST['ano'].'-'.$_POST['mes'].'-'.$_POST['dia'];
}
if(array_key_exists('enviar', $_POST)){
$fecha = $_POST['DtFecHor'];
}

if(array_key_exists('buscar', $_POST)){
$aula = $_POST['aula'];
}

if(array_key_exists('enviar', $_POST)){
$aula = $_POST['AuCodAul'];
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
$colname_evitaDupliPro = "-1";
if (isset($_POST['TxCodPro'])) {
  $colname_evitaDupliPro = $_POST['TxCodPro'];
}
mysql_select_db($database_conex, $conex);
$query_evitaDupliPro = sprintf("SELECT TxCodPro FROM horarios WHERE TxCodPro = %s", GetSQLValueString($colname_evitaDupliPro, "text"));
$evitaDupliPro = mysql_query($query_evitaDupliPro, $conex) or die(mysql_error());
$row_evitaDupliPro = mysql_fetch_assoc($evitaDupliPro);
$totalRows_evitaDupliPro = mysql_num_rows($evitaDupliPro);


$colname_evitaDupliHora = "-1";
if (isset($_POST['TmHorHor'])) {
  $colname_evitaDupliHora = $_POST['TmHorHor'];
}
mysql_select_db($database_conex, $conex);
$query_evitaDupliHora = sprintf("SELECT TxCodPro FROM horarios WHERE TmHorHor = %s AND AuCodAul='".$_POST['AuCodAul']."'", GetSQLValueString($colname_evitaDupliHora, "date"));
$evitaDupliHora = mysql_query($query_evitaDupliHora, $conex) or die(mysql_error());
$row_evitaDupliHora = mysql_fetch_assoc($evitaDupliHora);
$totalRows_evitaDupliHora = mysql_num_rows($evitaDupliHora);




if($totalRows_evitaDupliPro==0){ 
	if($totalRows_evitaDupliHora==0){
		$error = 0;
		if (array_key_exists ('enviar', $_POST) && !empty($_POST['TmHorHor']) && !empty($_POST['TxCodPro'])&& !empty($_POST['DtFecHor'])&& !empty($_POST['AuCodAul'])) {
			if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
				$insertSQL = sprintf("INSERT INTO horarios (AuCodHor, DtFecHor, TmHorHor, TxCodPro, AuCodAul) VALUES (%s, %s, %s, %s, %s)",
					GetSQLValueString($_POST['AuCodHor'], "int"),
					GetSQLValueString($_POST['DtFecHor'], "date"),
					GetSQLValueString($_POST['TmHorHor'], "text"),
					GetSQLValueString($_POST['TxCodPro'], "text"),
					GetSQLValueString($_POST['AuCodAul'], "int"));
						  mysql_select_db($database_conex, $conex);
						  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
						  $_POST=array();
			}
		}else{$error=1;}
	}else{$horaMax=1;}
}else{$proMax=1;}
mysql_select_db($database_conex, $conex);
$query_aulas = "SELECT * FROM aula ORDER BY TxNomAul ASC";
$aulas = mysql_query($query_aulas, $conex) or die(mysql_error());
$row_aulas = mysql_fetch_assoc($aulas);
$totalRows_aulas = mysql_num_rows($aulas);

mysql_select_db($database_conex, $conex);
$query_horasDisponibles = "SELECT horarios.AuCodHor, horarios.DtFecHor, horarios.TmHorHor, horarios.TxCodPro, aula.TxNomAul, aula.TxDirAul, horarios.AuCodAul FROM horarios, aula WHERE horarios.DtFecHor = '".$fecha."' AND horarios.AuCodAul ='".$aula."' AND aula.AuCodAul=horarios.AuCodAul";
$horasDisponibles = mysql_query($query_horasDisponibles, $conex) or die(mysql_error());
$row_horasDisponibles = mysql_fetch_assoc($horasDisponibles);
$totalRows_horasDisponibles = mysql_num_rows($horasDisponibles);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>organizar presentacion</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Asignar Horario de Presentaci&oacute;n</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td>
        <fieldset>
          <legend><h2>Obtener disponibilidad de hora y aula</h2></legend>
          <form name="form2" method="post" action="">
            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
            <?php if (array_key_exists ('enviar', $_POST) && $fecha == "") { echo '<p class="obligatorio">Debe obtener primeramente la disponibilidad de aulas por fechas</p>';}?>
              <tr>
                <td width="10%"><label for="dia">D&iacute;a:</label>
                  <select name="dia" class="textInput" id="dia" style="height:29px;">
                    <?php 
					  for ($i = 1; $i <= 31; $i++) {
   						 echo '<option value="'.$i.'">'.$i.'</option>';
						}
					  ?>
                </select></td>
                <td width="25%"><label for="mes2">Mes:
                  
                </label>
                  <select name="mes" class="textInput" id="mes2" style="height:30px;">
                    <option value="">Selecione una opcion</option>
                    <option value="01">Enero</option>
                    <option value="02">Febrero</option>
                    <option value="03">Marzo</option>
                    <option value="04">Abril</option>
                    <option value="05">Mayo</option>
                    <option value="06">Junio</option>
                    <option value="07">Julio</option>
                    <option value="08">Agosto</option>
                    <option value="09">Septiembre</option>
                    <option value="10">Octubre</option>
                    <option value="11">Noviembre</option>
                    <option value="12">Diciembre</option>
                  </select></td>
                <td width="10%"><label for="ano2">A&ntilde;o:
                  
                    
                </label>
                <input name="ano" type="text" class="textInput" id="ano2"></td>
                <td width="60%" align="left" valign="bottom">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="3"><label>Aula:</label>
                  <select name="aula" class="textInput" id="aula" style="height:31px;">
                    <option value="0">Seleccione una opcion</option>
                    <?php
do {  
?>
                    <option value="<?php echo $row_aulas['AuCodAul']?>"><?php echo $row_aulas['TxNomAul']?></option>
                    <?php
} while ($row_aulas = mysql_fetch_assoc($aulas));
  $rows = mysql_num_rows($aulas);
  if($rows > 0) {
      mysql_data_seek($aulas, 0);
	  $row_aulas = mysql_fetch_assoc($aulas);
  }
?>
                  </select></td>
                <td align="left" valign="bottom">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="3" align="right"><input name="buscar" type="submit" class="button" id="buscar" value="Buscar"></td>
                <td align="left" valign="bottom">&nbsp;</td>
              </tr>
            </table>
          </form>
        </fieldset>
        <fieldset>
                <legend><h2>Detalle de horarios</h2></legend>
                <table width="100%" border="0" cellpadding="10" cellspacing="0">
                <?php if (array_key_exists ('enviar', $_POST) && $proMax==1) { echo '<p class="obligatorio">*El c&oacute;digo de proyecto ingresado ya tiene asignado lugar, fecha y hora de presentaci&oacute;n</p>';}?>
                      <?php if (array_key_exists ('enviar', $_POST) && $horaMax==1) { echo '<p class="obligatorio">**El aula esta ocupada para la hora seleccionada';}?>
            		  <?php if (array_key_exists ('enviar', $_POST) && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
          <tr>
            <td>
                <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
                  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="10">
                    <tr valign="baseline">
                      <td colspan="3"><h3>
                        
                          Asignar horario de presentaci&oacute;n <?php if ($totalRows_horasDisponibles > 0) { // Show if recordset not empty ?>para el <?php echo $fecha; ?> en el Aula <?php echo $row_horasDisponibles['TxNomAul'] ?>
  <?php } // Show if recordset not empty ?>
                      </h3>
                      </td>
                    </tr>
                    <tr valign="baseline">
                      <td width="10%"><label>C&oacute;digo de Proyecto:
                        <?php if (array_key_exists ('enviar', $_POST) && $_POST['TxCodPro'] == "") { echo $icono;}?>
                      </label>
                      <input name="TxCodPro" type="text" class="textInput" value="" size="32"></td>
                      <td width="15%"><label for="TmHorHor">Hora:</label>
                        <select name="TmHorHor" class="textInput" id="TmHorHor" style="height:31px;">
                          <?php 
					 		$intervalo=0;
                for ( $i = 1 ; $i <= 17 ; $i ++) {
                		$hora = (date('H:i:s',strtotime('07:00:00 + '.$intervalo.' min')));
				 			$intervalo=$intervalo+45; 
								echo '<option value="'.$hora.'">'.date('h:i a',strtotime($hora)).'</option>';
				 		}
				 ?>
                        </select>
                        <input name="DtFecHor" type="hidden" id="DtFecHor" value="<?php echo $fecha ?>">
                        <input name="AuCodAul" type="hidden" id="AuCodAul" value="<?php echo $aula; ?>"></td>
                      <td width="10%" align="right" valign="bottom"><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar"></td>
                    </tr>
                  </table>
                  <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
                    <tr>
                      <td colspan="9"><h3>Detalle de horas ocupadas</h3></td>
                    </tr>
                    <?php if ($totalRows_horasDisponibles == 0) { // Show if recordset empty ?>
                      <tr>
                        <td colspan="9"><p>Todas las horas se encuentran disponibles</p></td>
                      </tr>
                      <?php } // Show if recordset empty ?>
                    <?php if ($totalRows_horasDisponibles > 0) { // Show if recordset not empty ?>
                      <tr class="Tcabeza">
                        <th width="10%">Fecha</th>
                        <th width="5%">Hora</th>
                        <th width="10%">Proyecto</th>
                        <th width="5%">Aula</th>
                        <th width="30%" align="left">Direcci&oacute;n</th>
                        <th width="35%" align="left">Docentes</th>
                        <th width="5%">Eliminar</th>
                      </tr>
                      <?php } // Show if recordset not empty ?>
                    <?php 
					$aux=$row_horasDisponibles['TxCodPro']."x";
					do { ?>
                      <tr align="left">
                        <td width="5%" align="center" <?php if($aux=$row_horasDisponibles['TxCodPro']){echo 'class="lineaInfPunta"';}?>><?php echo $row_horasDisponibles['DtFecHor']; ?></td>
                        <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_horasDisponibles['TmHorHor']; ?></td>
                        <td width="10%" align="center" class="lineaInfPunta"><?php echo $row_horasDisponibles['TxCodPro']; ?></td>
                        <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_horasDisponibles['TxNomAul']; ?></td>
                        <td width="30%" class="lineaInfPunta" align="left"><?php echo $row_horasDisponibles['TxDirAul']; ?></td>
                        <td width="35%" class="lineaInfPunta" align="left">
                        <?php mysql_select_db($database_conex, $conex);
								$query_doc = "SELECT NuCedDoc, TxApeDoc, TxNomDoc, jurado.TxCodPro, proyecto.TxCodPro FROM docente, jurado, proyecto WHERE docente.NuCedDoc=jurado.TxCedDoc AND proyecto.TxCodPro=jurado.TxCodPro AND proyecto.TxCodPro = '".$row_horasDisponibles['TxCodPro']."'";
								$doc = mysql_query($query_doc, $conex) or die(mysql_error());
								$row_doc = mysql_fetch_assoc($doc);
								$totalRows_doc = mysql_num_rows($doc);
						?>
                        
                        <?php do { ?>
    
      <?php echo $row_doc['NuCedDoc']; ?> - 
      <?php echo $row_doc['TxApeDoc']; ?>, 
      <?php echo $row_doc['TxNomDoc']; ?><br>
    
    <?php } while ($row_doc = mysql_fetch_assoc($doc)); ?>
                        
                        
                        </td>
                        <td width="5%" align="center" class="lineaInfPunta"><a href="del-hora.php?hora=<?php echo $row_horasDisponibles['AuCodHor']; ?>&fecha=<?php echo $row_horasDisponibles['DtFecHor']; ?>&aula=<?php echo $row_horasDisponibles['AuCodAul']; ?>"><span class="icon-del">&nbsp;</span></a></td>
                      </tr>
                      <?php 
					  
					  $aux=$row_horasDisponibles['TxCodPro'];
					  } while ($row_horasDisponibles = mysql_fetch_assoc($horasDisponibles)); ?>
                  </table>
                  <input type="hidden" name="MM_insert" value="form1">
                </form>
              </td>
          </tr>
        </table></fieldset></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td></td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($aulas);

mysql_free_result($horasDisponibles);

mysql_free_result($evitaDupliHora);

mysql_free_result($evitaDupliPro);

mysql_free_result($doc);
?>