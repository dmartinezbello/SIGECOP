<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
// Juego de registro que permitira verificar si ya esta registrada la linea de investigacion
$colname_lineasInv = "-1";
if (isset($_POST['TxNomLin'])) {
  $colname_lineasInv = $_POST['TxNomLin'];
}
mysql_select_db($database_conex, $conex);
$query_lineasInv = sprintf("SELECT TxNomLin FROM linea WHERE TxNomLin = %s", GetSQLValueString($colname_lineasInv, "text"));
$lineasInv = mysql_query($query_lineasInv, $conex) or die(mysql_error());
$row_lineasInv = mysql_fetch_assoc($lineasInv);
$totalRows_lineasInv = mysql_num_rows($lineasInv);

mysql_select_db($database_conex, $conex);
$query_contadorLinea = "SELECT AuCodLin FROM linea";
$contadorLinea = mysql_query($query_contadorLinea, $conex) or die(mysql_error());
$row_contadorLinea = mysql_fetch_assoc($contadorLinea);
$totalRows_contadorLinea = mysql_num_rows($contadorLinea);
$linea=$totalRows_contadorLinea+1;
// Validar que se les hayan colocado datos a los campos requeridos
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxNomLin'])){
// Validar que no se incluyan datos duplicados
if ($totalRows_lineasInv == 0){
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO linea (AuCodLin, TxNomLin) VALUES (%s, %s)",
                       GetSQLValueString($linea, "int"),
                       GetSQLValueString($_POST['TxNomLin'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  header ('Location: area.php?linea='.$linea);
  exit;
  $_POST = array();
}
}
}else {if (array_key_exists ('enviar', $_POST)){$error=1;}}
mysql_select_db($database_conex, $conex);
$query_especialidades = "SELECT * FROM especialidad ORDER BY TxNomEsp ASC";
$especialidades = mysql_query($query_especialidades, $conex) or die(mysql_error());
$row_especialidades = mysql_fetch_assoc($especialidades);
$totalRows_especialidades = mysql_num_rows($especialidades);

mysql_select_db($database_conex, $conex);
$query_DetalleLineas = "SELECT * FROM linea ORDER BY TxNomLin ASC";
$DetalleLineas = mysql_query($query_DetalleLineas, $conex) or die(mysql_error());
$row_DetalleLineas = mysql_fetch_assoc($DetalleLineas);
$totalRows_DetalleLineas = mysql_num_rows($DetalleLineas);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>Registro lineas de investigacion</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Registrar Lineas de Investigaci&oacute;n</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td>
        <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
          <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
          		<?php if ($_POST && $totalRows_lineasInv > 0) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$duplicado.'</td></tr>';}?>
              	<?php if ($_POST && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
            <tr valign="baseline">
                 <td width="10%" nowrap><h2>Datos de l&iacute;nea de investigaci&oacute;n</h2></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" align="right" nowrap><label>Linea de investigaci&oacute;n:
<?php if ($_POST && $_POST['TxNomLin'] == "") { echo $icono;}?>
                <?php if ($_POST && $totalRows_lineasInv > 0) { echo $iconoAzul;}?>
                </label>
              <input name="TxNomLin" type="text" class="textInput" value="<?php if (isset($_POST['TxNomLin'])) {echo htmlentities($_POST['TxNomLin']);} ?>" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td align="right" nowrap><input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
                <input name="Restablecer" type="reset" class="button der" value="Restablecer">
              <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" /></td>
            </tr>
          </table>
          <input type="hidden" name="AuCodLin" value="">
          <input type="hidden" name="MM_insert" value="form1">
        </form>
        <p>&nbsp;</p>
        <table width="95%" border="0" align="center" cellpadding="10" cellspacing="1">
          <tr>
            <th colspan="2" align="left"><h2>Lineas de investigaci&oacute;n registradas</h2></th>
          </tr>
          <tr>
            <th width="95%" align="left" class="Tcabeza">Linea de investigaci&oacute;n</th>
            <th width="5%" class="Tcabeza">Editar</th>
          </tr>
          <?php do { ?>
            <tr>
              <td width="95%" class="lineaInfPunta"><?php echo $row_DetalleLineas['TxNomLin']; ?></td>
              <td width="5%" align="center" class="lineaInfPunta"><a href="area.php?linea=<?php echo $row_DetalleLineas['AuCodLin']; ?>">editar</a></td>
            </tr>
            <?php } while ($row_DetalleLineas = mysql_fetch_assoc($DetalleLineas)); ?>
        </table></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($especialidades);

mysql_free_result($DetalleLineas);

mysql_free_result($contadorLinea);

mysql_free_result($lineasInv);
?>
