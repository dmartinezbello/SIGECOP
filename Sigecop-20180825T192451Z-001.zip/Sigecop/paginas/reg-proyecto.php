<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
//Obtener Trayecto del area de desarrollo

$colname_trayecto = "-1";
if (isset($_POST['AuCodAre'])) {
  $colname_trayecto = $_POST['AuCodAre'];
}
mysql_select_db($database_conex, $conex);
$query_trayecto = sprintf("SELECT TxTraAre FROM area WHERE AuCodAre = %s", GetSQLValueString($colname_trayecto, "int"));
$trayecto = mysql_query($query_trayecto, $conex) or die(mysql_error());
$row_trayecto = mysql_fetch_assoc($trayecto);
$totalRows_trayecto = mysql_num_rows($trayecto);

//Obtener siglas de la especialidad
$colname_obtenerSigla = "-1";
if (isset($_POST['especialidad'])) {
  $colname_obtenerSigla = $_POST['especialidad'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerSigla = sprintf("SELECT TxSigEsp FROM especialidad WHERE AuCodEsp = %s", GetSQLValueString($colname_obtenerSigla, "int"));
$obtenerSigla = mysql_query($query_obtenerSigla, $conex) or die(mysql_error());
$row_obtenerSigla = mysql_fetch_assoc($obtenerSigla);
$totalRows_obtenerSigla = mysql_num_rows($obtenerSigla);
$esp=$row_obtenerSigla['TxSigEsp']; // obtener las siglas de la especialidad seleccionada en el combo especialidad
$ano=date('Y');// Declarar el ano actual de registro del proyecto
$colname_obtenerSigla = "-1";
if (isset($_POST['especialidad'])) {
  $colname_obtenerSigla = $_POST['especialidad'];
}
mysql_select_db($database_conex, $conex);
$query_proyecto = "SELECT *  FROM  `proyecto`  WHERE  `TxCodPro` LIKE CONVERT( _utf8 '%".$esp.$ano."%' USING latin1 )  COLLATE latin1_spanish_ci";
$proyecto = mysql_query($query_proyecto, $conex) or die(mysql_error());
$row_proyecto = mysql_fetch_assoc($proyecto);
$totalRows_proyecto = mysql_num_rows($proyecto);


//Generar el codigo que se le va asignar al proyecto
$trayect='T'.$row_trayecto['TxTraAre'];
$numero=$totalRows_proyecto+1;
$codigo=$esp.$ano.$trayect.' - '.str_pad($numero, 4, 0, STR_PAD);
$_POST['TxConPro']=0;

// Validar que se les hayan colocado datos a los campos requeridos y que se haya indroducido un email en el campo email
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxTitPro']) && !empty($_POST['AuCodAre']) && !empty($_POST['AuNomIns'])) {
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO proyecto (TxCodPro, TxTitPro, DtRegPro, TxConPro, AuCodAre, AuNomIns, TxEstPro) VALUES (%s, %s, %s, %s, %s, %s,%s)",
                       GetSQLValueString($codigo, "text"),
                       GetSQLValueString($_POST['TxTitPro'], "text"),
                       GetSQLValueString($_POST['DtRegPro'], "date"),
                       GetSQLValueString("0", "text"),
                       GetSQLValueString($_POST['AuCodAre'], "int"),
                       GetSQLValueString($_POST['AuNomIns'], "int"),
							  GetSQLValueString($_POST['TxEstPro'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  header ('Location: reg-est-tut-pro.php?proyecto='.$codigo);
  exit;
  $_POST = array();
}
}else {$error=1;}
mysql_select_db($database_conex, $conex);
$query_especialidad = "SELECT * FROM especialidad ORDER BY TxNomEsp ASC";
$especialidad = mysql_query($query_especialidad, $conex) or die(mysql_error());
$row_especialidad = mysql_fetch_assoc($especialidad);
$totalRows_especialidad = mysql_num_rows($especialidad);

mysql_select_db($database_conex, $conex);
$query_estado = "SELECT * FROM estado ORDER BY TxDesEst ASC";
$estado = mysql_query($query_estado, $conex) or die(mysql_error());
$row_estado = mysql_fetch_assoc($estado);
$totalRows_estado = mysql_num_rows($estado);

?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>registrar de proyecto</title>
  <script type="text/javascript" src="../js/ajax.js"></script>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>
<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Registrar Proyecto</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td>
        <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
          <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
          	<?php if (array_key_exists ('enviar', $_POST) && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
            <tr valign="baseline">
              <td colspan="3" nowrap><h2>Datos del proyecto</h2></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" align="left" nowrap>&nbsp;</td>
              <td width="25%">&nbsp;</td>
              <td width="25%"><label>Estatus del Proyecto:</label>
                <select name="TxEstPro" class="textInput" id="TxEstPro" style="height:31px;">
                <option value="p">Iniciando</option>
                <option value="e">En revision</option>
                <option value="c">Condicionado</option>
              </select></td>
            </tr>
            <tr valign="baseline">
              <td colspan="3" nowrap><label>T&iacute;tulo:<?php if (array_key_exists ('enviar', $_POST) && $_POST['TxTitPro'] == "") { echo $icono;}?></label>
                <textarea name="TxTitPro" cols="32" rows="3" class="anchoFull"><?php if (isset($_POST['TxTitPro'])) {echo htmlentities($_POST['TxTitPro']);}?></textarea></td>
            </tr>
            <tr valign="baseline">
              <td colspan="3" nowrap><h2>L&iacute;nea de investigaci&oacute;n y desarrollo</h2></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" align="right" nowrap><label for="especialidad">Especialidad:
                <?php if (array_key_exists ('enviar', $_POST) && $_POST['AuCodAre'] == "") { echo $icono;}?>
              </label>
                <select name="especialidad" class="textInput" id="especialidad" onChange="carga_linea_investigacion(this.value)">
                  <option value="0">Seleccione una opcion</option>
                  <?php
do {  
?>
                  <option value="<?php echo $row_especialidad['AuCodEsp']?>"><?php echo $row_especialidad['TxNomEsp']?></option>
                  <?php
} while ($row_especialidad = mysql_fetch_assoc($especialidad));
  $rows = mysql_num_rows($especialidad);
  if($rows > 0) {
      mysql_data_seek($especialidad, 0);
	  $row_especialidad = mysql_fetch_assoc($especialidad);
  }
?>
              </select></td>
              <td colspan="2"><div id="linea"></div></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" align="left" nowrap>
              <div id="area"></div>
              </td>
              <td colspan="2">&nbsp;</td>
            </tr>
            <tr valign="baseline">
              <td colspan="3" align="left" nowrap><h2>Contexto geogr&aacute;fico</h2></td>
            </tr>
            <tr valign="baseline">
              <td nowrap><label>Estado:
                <?php if (array_key_exists ('enviar', $_POST) && $_POST['AuNomIns'] == "") { echo $icono;}?>
              </label>
                <select name="cont" class="textInput" id="cont" onChange="load(this.value)">
                  <option value="0">Seleccione una opci&oacute;n</option>
                  <?php
do {  
?>
<option value="<?php echo $row_estado['NuCodEst']?>"><?php echo $row_estado['TxDesEst']?></option>
                  <?php
} while ($row_estado = mysql_fetch_assoc($estado));
  $rows = mysql_num_rows($estado);
  if($rows > 0) {
      mysql_data_seek($estado, 0);
	  $row_estado = mysql_fetch_assoc($estado);
  }
?>
                </select></td>
              <td colspan="2"><div id="myDiv"></div></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" align="right" nowrap><div id="parroquias"></div></td>
              <td colspan="2"><div id="comunidad"></div></td>
            </tr>
            <tr valign="baseline">
              <td colspan="3" align="right" nowrap>
              <input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
              <input name="Restablecer" type="reset" class="button der" value="Restablecer">
              <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" />&nbsp;</td>
            </tr>
          </table>
          <input type="hidden" name="DtRegPro" value="">
          <input type="hidden" name="MM_insert" value="form1">
        </form>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($especialidad);

mysql_free_result($estado);

mysql_free_result($trayecto);

mysql_free_result($proyecto);

mysql_free_result($obtenerSigla);
?>