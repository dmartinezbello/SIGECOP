<?php require_once('../Connections/conex.php'); ?>
<?php include('mensajes.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
// Validar que se les hayan colocado datos a los campos requeridos
$error = 0;
if (array_key_exists ('enviar', $_POST) && !empty($_POST['TxNomIns']) && !empty($_POST['TxComIns']) && !empty($_POST['NuCodPar'])){
// Validar que no se incluyan datos duplicados
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO institucion (AuCodIns, TxNomIns, TxComIns, NuCodPar) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodIns'], "int"),
                       GetSQLValueString(ucwords($_POST['TxNomIns']), "text"),
                       GetSQLValueString(ucwords($_POST['TxComIns']), "text"),
                       GetSQLValueString($_POST['NuCodPar'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  $_POST = array();
  echo "<script language='JavaScript'> alert('El proceso de registro se realizo con exito');</script>";
}
}else {$error=1;}
mysql_select_db($database_conex, $conex);
$query_estado = "SELECT * FROM estado ORDER BY TxDesEst ASC";
$estado = mysql_query($query_estado, $conex) or die(mysql_error());
$row_estado = mysql_fetch_assoc($estado);
$totalRows_estado = mysql_num_rows($estado);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>registro de instituciones o comunidades</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
  <script type="text/javascript" src="../js/ajax.js"></script>
</head>

<body>
  <table width="100%">
    <tr>
      <td align="center"><h3>Registrar Comunidad o Instituci&oacute;n</h3></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
    <tr>
      <td>
        <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
          <table width="95%" border="0" align="center" cellpadding="0" cellspacing="10">
          <?php if ($_POST && $error ==1) { echo '<tr valign="baseline"><td colspan="2" nowrap>'.$incompleto.'</td></tr>';}?>
            <tr valign="baseline">
              <td colspan="2" align="left" nowrap><h2>Datos de comunidades o instituciones</h2></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" align="right" nowrap><label>Institucion o consejo comunal:</label>
                <input name="TxNomIns" type="text" class="textInput" value="<?php if (isset($_POST['TxNomIns'])) {echo htmlentities($_POST['TxNomIns']);} ?>" size="32"></td>
              <td width="50%"><label>Comunidad:</label>
              <input name="TxComIns" type="text" class="textInput" value="<?php if (isset($_POST['TxComIns'])) {echo htmlentities($_POST['TxComIns']);} ?>" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td colspan="2" nowrap><h2>Ubicaci&oacute;n geogr&aacute;fica</h2></td>
            </tr>
            <tr valign="baseline">
              <td nowrap>
              <label>Estado:</label>
              <select name="cont" class="textInput" id="cont" onChange="load(this.value)">
              <option value="0">Seleccione una opci&oacute;n</option>
                <?php
do {  
?>
                <option value="<?php echo $row_estado['NuCodEst']?>"><?php echo $row_estado['TxDesEst']?></option>
                <?php
} while ($row_estado = mysql_fetch_assoc($estado));
  $rows = mysql_num_rows($estado);
  if($rows > 0) {
      mysql_data_seek($estado, 0);
	  $row_estado = mysql_fetch_assoc($estado);
  }
?>
              </select></td>
              <td><div id="myDiv"></div></td>
            </tr>
            <tr valign="baseline">
              <td width="50%" align="right" nowrap><div id="parroquias"></div></td>
              <td>&nbsp;</td>
            </tr>
            <tr valign="baseline">
              <td colspan="2" nowrap>
              <input name="enviar" type="submit" class="button der" id="enviar" value="Registrar">
              <input name="Restablecer" type="reset" class="button der" value="Restablecer">
              <input type="button" class="button der" onClick="location.href='principal.php'" value="Cancelar" />
</td>
            </tr>
          </table>
          <input type="hidden" name="AuCodIns" value="">
          <input type="hidden" name="MM_insert" value="form1">
        </form>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td class="Tcabeza">&nbsp;</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($estado);
?>
