<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
<title>.:SIGECOP:.</title>
</head>
<frameset rows="120,*,53" cols="*" framespacing="1" frameborder="yes" border="1" bordercolor="#ececec">
  <frame src="cabecera.php" name="topFrame" scrolling="auto" noresize title="MarcoSuperior">
  <frameset rows="*" cols="240,*,240" framespacing="1" frameborder="yes" border="1">
    <frame src="MarcoIzquierdo.php" name="leftFrame" scrolling="SI" noresize title="MarcoIzquierdo">
    <frame src="principal.php" name="mainFrame" title="MarcoCentral">
  <frame src="MarcoDerecho.php"></frameset>
<frame src="pie.php"></frameset>
<noframes><body>
</body></noframes>
</html>
