<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
  <title>.:SIGECOP:.</title>
  <link href="../css/Sigecop.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0">
  <tr>
    <td colspan="2" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><h1>Visi&oacute;n</h1></td>
  </tr>
  <tr>
    <td width="10%"><img src="../fotos/BP1-300x238.jpg" alt="hombrecillo" width="197" height="157" class="der"></td>
    <td width="90%"><p>Contribuir con el  cumplimiento del Encargo Social que la Universidad tiene, as&iacute; mismo, propiciar  el desarrollo de la ciencia, la tecnolog&iacute;a y la innovaci&oacute;n en el Instituto  Universitario de Tecnolog&iacute;a Cuman&aacute; Extensi&oacute;n Punta de Mata, tomando como  bandera el fortalecimiento acad&eacute;mico e investigativo de los docentes, docentes  investigadores y auxiliares docentes adscritos a esta secci&oacute;n.&nbsp; </p></td>
  </tr>
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="90%">&nbsp;</td>
  </tr>
</table>
</body>
</html>