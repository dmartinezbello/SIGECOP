<?php
function nuevoComentario($correoEst, $correoDoc, $comentario, $usuario){
  include("class.phpmailer.php");
  include("class.smtp.php");

  $mail = new PHPMailer();
  $mail->IsSMTP();
  $mail->SMTPAuth = true;
  $mail->SMTPSecure = "ssl";
  $mail->Host = "smtp.gmail.com";
  $mail->Port = 465;
  $mail->Username = "sigecop@gmail.com";
  $mail->Password = "19037064";
  $mail->SMTPDebug = 1; //anadido para mostrar informaci�n detallada de error en caso de producirse
  
  $mail->From = "sigecop@gmail.com";
  $mail->FromName = "Sistema de gestion y control de proyectos UPT Ludovico Silva Punta de Mata";
  $mail->Subject = "Hay un nuevo comentario en tu proyecto";
  $mail->MsgHTML('
<table width="715" border="0" cellspacing="10" cellpadding="0" style="font-family: Trebuchet MS, Arial, Helvetica, sans-serif; font-size: 12px; text-align:justify;">
  <tr>
    <td valign="top" bgcolor="#F0F0F0"><img src="https://lh5.googleusercontent.com/-TLMXQtd9ymM/UcklZ-uHtTI/AAAAAAAAChw/1qZYFRTOdpo/w879-h91-no/CabeceraSigecop.PNG" alt="Sigecop" width="715" height="73" longdesc="https://lh3.googleusercontent.com/-nVb3LURTtrg/Uckdukhe_4I/AAAAAAAAACE/IIQ4UIKS4TI/w1111-h71-no/CabeceraSigecop.PNG"></td>
  </tr>
  <tr>
    <td style="padding:10px;"><p>Hola, han comentado un proyecto donde estas relacionado.</p>
      <p>'.$comentario.'</p>
      <br>
      <p><strong>------- NOTA -------</strong></p>
      <p>Si has recibido este mensaje de correo electr&oacute;nico por error, es probable que otro usuario haya utilizado accidentalmente tu direcci&oacute;n de correo electr&oacute;nico. </p></td>
  </tr>
  <tr>
    <td height="50" align="center" bgcolor="#F0F0F0">Sistema de gesti&oacute;n y control de proyectos de la Univertidad Politecnica Territorial del Norte de Monagas &quot;Ludovico Silva&quot;</td>
  </tr>
</table>

  ');
  
  //Enviar email a estudiantes
	foreach($correoEst as $elemento){
	 $mail->AddAddress($elemento);
	 $mail->IsHTML(true);
     $mail->Send(); 
	  }
	//Enviar email a estudiantes
  foreach($correoDoc as $elemento){
	 $mail->AddAddress($elemento);
	 $mail->IsHTML(true);
     $mail->Send(); 
	  }
	
  //$mail->AddAddress($correoEst);
  //$mail->AddCC($correoDoc);
  
}
?>