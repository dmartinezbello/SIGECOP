<?php
//incluir el codigo de la clase PHPMailer
function confirmarRelacionProyecto($correo, $codigo, $titulo){
  include("class.phpmailer.php");
  include("class.smtp.php");

  $mail = new PHPMailer();
  $mail->IsSMTP();
  $mail->SMTPAuth = true;
  $mail->SMTPSecure = "ssl";
  $mail->Host = "smtp.gmail.com";
  $mail->Port = 465;
  $mail->Username = "sigecop@gmail.com";
  $mail->Password = "19037064";
  $mail->SMTPDebug = 1; //anadido para mostrar informaci�n detallada de error en caso de producirse
  
  $mail->From = "sigecop@gmail.com";
  $mail->FromName = "Sistema de gestion y control de proyectos UPT Ludovico Silva Punta de Mata";
  $mail->Subject = "Notificacion";
  $mail->MsgHTML('
  <table width="715" border="0" cellspacing="10" cellpadding="0" style="font-family: Trebuchet MS, Arial, Helvetica, sans-serif; font-size: 12px; text-align:justify;">
    <tr>
      <td valign="top" bgcolor="#F0F0F0"><img src="https://lh5.googleusercontent.com/-TLMXQtd9ymM/UcklZ-uHtTI/AAAAAAAAChw/1qZYFRTOdpo/w879-h91-no/CabeceraSigecop.PNG" alt="Sigecop" width="715" height="73" longdesc="https://lh3.googleusercontent.com/-nVb3LURTtrg/Uckdukhe_4I/AAAAAAAAACE/IIQ4UIKS4TI/w1111-h71-no/CabeceraSigecop.PNG"></td>
    </tr>
    <tr>
      <td style="padding:10px;"><p>Mediante el siguiente queremos informarle  que usted ha sido relacionado con el proyecto socio tecnol&oacute;gico:<strong> '.$titulo.' </strong> al mismo le fue asignado el codigo: <strong style="color:red;">'.$codigo.'</strong></p>
      <p>Saludos coordiales, </p><br>
      <p><strong>------- NOTA -------</strong></p>
      <p>Si has recibido este mensaje de correo electr&oacute;nico por error, es probable que otro usuario haya utilizado accidentalmente tu direcci&oacute;n de correo electr&oacute;nico.      </p></td>
    </tr>
    <tr>
      <td height="50" align="center" bgcolor="#F0F0F0">Sistema de gesti&oacute;n y control de proyectos de la Univertidad Politecnica Territorial del Norte de Monagas &quot;Ludovico Silva&quot;</td>
    </tr>
  </table>
  ');
  $mail->AddAddress($correo);
  $mail->IsHTML(true);
     
  if(!$mail->Send()) {
   
  } 
}
?>
