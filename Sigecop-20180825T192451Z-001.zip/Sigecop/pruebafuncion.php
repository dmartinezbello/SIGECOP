<?php 
require('phpmailer/correos.php');
$correosss='DMArtinezBello@gmail.com';
$proyecto = 'PNFI - 0002';
$titulo='esta es una prueba del titulo de mi proyecto';
confirmarRelacionProyecto($correosss, $proyecto, $titulo);
 ?>