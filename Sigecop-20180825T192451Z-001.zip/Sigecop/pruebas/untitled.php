<?php require_once('../Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO seguimiento (AuCodSeg, TxComSeg, DtRegSeg, TxCodSeg, TxLogSeg) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodSeg'], "int"),
                       GetSQLValueString($_POST['TxComSeg'], "text"),
                       GetSQLValueString($_POST['DtRegSeg'], "date"),
                       GetSQLValueString($_POST['TxCodSeg'], "text"),
                       GetSQLValueString($_POST['TxLogSeg'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Untitled Document</title>
</head>

<body>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right">AuCodSeg:</td>
      <td><input type="text" name="AuCodSeg" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">TxComSeg:</td>
      <td><input type="text" name="TxComSeg" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">DtRegSeg:</td>
      <td><input type="text" name="DtRegSeg" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">TxCodSeg:</td>
      <td><input type="text" name="TxCodSeg" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">TxLogSeg:</td>
      <td><input type="text" name="TxLogSeg" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="Insert record"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1">
</form>
<p>&nbsp;</p>
</body>
</html>